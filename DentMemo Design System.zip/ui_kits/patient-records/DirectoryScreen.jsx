function RowMenu({onMerge,onDelete,visitCount}){
  const [open,setOpen]=React.useState(false);
  const [confirm,setConfirm]=React.useState(false);
  const label=confirm?`Confirm delete (+ ${visitCount} visit${visitCount===1?'':'s'})`:visitCount===0?'Delete patient':'Delete patient…';
  return (
    <div style={{position:'relative'}}>
      <button onClick={()=>setOpen(!open)} style={{padding:'3px 8px',fontSize:13,fontWeight:700,background:'none',border:'1.5px solid var(--border)',borderRadius:6,cursor:'pointer',color:'var(--muted)'}}>⋯</button>
      {open?(
        <div onMouseLeave={()=>{setOpen(false);setConfirm(false);}} style={{position:'absolute',top:'100%',right:0,background:'#fff',border:'1.5px solid var(--border)',borderRadius:8,boxShadow:'var(--shadow)',zIndex:30,minWidth:170,overflow:'hidden'}}>
          <div onClick={()=>{onMerge();setOpen(false);}} style={{padding:'8px 12px',fontSize:12,cursor:'pointer',color:'var(--ink)'}}>Select to merge</div>
          <div onClick={()=>{ if(confirm){onDelete();setOpen(false);setConfirm(false);} else {setConfirm(true);} }} style={{padding:'8px 12px',fontSize:12,cursor:'pointer',color:'var(--red)',fontWeight:confirm?700:400,background:confirm?'#fee2e2':'transparent'}}>{label}</div>
        </div>
      ):null}
    </div>
  );
}
function DirectoryScreen({patients,setPatients,visits,setVisits,treatments,doctorMode}){
  const {inputSm,fmtA,initials,genderColor}=window.dmHelpers;
  const [q,setQ]=React.useState('');
  const [editing,setEditing]=React.useState(null);
  const [adding,setAdding]=React.useState(false);
  const [newP,setNewP]=React.useState({name:'',age:'',gender:'',phone:''});
  const [merge,setMerge]=React.useState([]);

  const visitCount=pid=>visits.filter(v=>v.patientId===pid).length;
  const filtered=patients.filter(p=>p.name.toLowerCase().includes(q.toLowerCase())||p.phone.includes(q));

  const saveField=(id,field,val)=>setPatients(patients.map(p=>p.id===id?{...p,[field]:val}:p));
  const toggleMerge=id=>setMerge(m=>m.includes(id)?m.filter(x=>x!==id):m.length<2?[...m,id]:m);
  const doMerge=()=>{
    if(merge.length!==2)return;
    const [keepId,dropId]=merge;
    setVisits(visits.map(v=>v.patientId===dropId?{...v,patientId:keepId}:v));
    setPatients(patients.filter(p=>p.id!==dropId));
    setMerge([]);
  };
  const addPatient=()=>{
    if(!newP.name)return;
    const nid=Math.max(0,...patients.map(p=>p.id))+1;
    setPatients([...patients,{id:nid,pid:'PT-'+(10000+nid),name:newP.name,age:+newP.age||0,gender:newP.gender,phone:newP.phone}]);
    setNewP({name:'',age:'',gender:'',phone:''});
    setAdding(false);
  };
  const delPatient=id=>{
    setVisits(visits.filter(v=>v.patientId!==id));
    setPatients(patients.filter(p=>p.id!==id));
  };

  return (
    <div>
      <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:10,alignItems:'flex-end'}}>
        <div style={{flex:1,minWidth:160}}><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Name or phone…" style={inputSm}/></div>
        <span style={{fontSize:12,color:'var(--muted)',paddingBottom:8}}>{filtered.length} patients</span>
        <button onClick={()=>setAdding(true)} style={{padding:'5px 10px',borderRadius:7,fontSize:11,fontWeight:700,cursor:'pointer',border:'none',background:'var(--teal)',color:'#fff'}}>+ Add</button>
      </div>
      {merge.length>0?(
        <div style={{background:'var(--teal)',color:'#fff',padding:'10px 14px',borderRadius:10,marginBottom:10,display:'flex',justifyContent:'space-between',alignItems:'center',gap:10,fontSize:12,fontWeight:600}}>
          <span>{merge.length===1?'Select one more to merge':'Ready to merge — first selected patient is kept'}</span>
          <div style={{display:'flex',gap:6}}>
            <button onClick={()=>setMerge([])} style={{padding:'5px 10px',borderRadius:7,fontSize:11,background:'rgba(255,255,255,.2)',color:'#fff',border:'none',cursor:'pointer'}}>Cancel</button>
            <button onClick={doMerge} disabled={merge.length!==2} style={{padding:'5px 10px',borderRadius:7,fontSize:11,fontWeight:700,background:'#fff',color:'var(--teal)',border:'none',cursor:'pointer',opacity:merge.length!==2?.5:1}}>Merge</button>
          </div>
        </div>
      ):null}
      {adding?(
        <div style={{background:'var(--amber-l)',border:'1px solid var(--amber)',borderRadius:10,padding:12,marginBottom:10,display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(120px,1fr))',gap:8}}>
          <input value={newP.name} onChange={e=>setNewP({...newP,name:e.target.value})} placeholder="Full name" style={inputSm}/>
          <select value={newP.gender} onChange={e=>setNewP({...newP,gender:e.target.value})} style={inputSm}><option value="">Gender</option><option value="M">Male</option><option value="F">Female</option></select>
          <input value={newP.age} onChange={e=>setNewP({...newP,age:e.target.value})} placeholder="Age" style={inputSm}/>
          <input value={newP.phone} onChange={e=>setNewP({...newP,phone:e.target.value})} placeholder="Phone" style={inputSm}/>
          <div style={{display:'flex',gap:6,gridColumn:'1/-1'}}>
            <button onClick={()=>setAdding(false)} style={{padding:'6px 12px',borderRadius:8,fontSize:12,border:'1.5px solid var(--border)',background:'#fff',cursor:'pointer'}}>Cancel</button>
            <button onClick={addPatient} style={{padding:'6px 12px',borderRadius:8,fontSize:12,fontWeight:700,border:'none',background:'var(--green)',color:'#fff',cursor:'pointer'}}>✓ Add Patient</button>
          </div>
        </div>
      ):null}
      <div style={{background:'#fff',border:'1.5px solid var(--border)',borderRadius:14,boxShadow:'var(--shadow)',overflow:'hidden'}}>
        <div style={{overflowX:'auto'}}>
          <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
            <thead><tr>{['ID','Name','Age','Gender','Phone','Visits',''].map(h=><th key={h} style={{padding:'8px 10px',textAlign:'left',fontSize:10,color:'var(--muted)',textTransform:'uppercase',background:'var(--bg)'}}>{h}</th>)}</tr></thead>
            <tbody>
              {filtered.map(p=>(
                <tr key={p.id} style={{borderBottom:'1px solid var(--border)',background:merge.includes(p.id)?'var(--teal-l)':'transparent'}}>
                  <td style={{padding:'8px 10px',fontFamily:'var(--font-mono)',color:'var(--teal)',fontWeight:700}}>{p.pid}</td>
                  <td style={{padding:'8px 10px'}}>{editing===p.id+'-name'?<input autoFocus defaultValue={p.name} onBlur={e=>{saveField(p.id,'name',e.target.value);setEditing(null);}} style={{...inputSm,padding:'2px 4px'}}/>:<span onClick={()=>setEditing(p.id+'-name')} style={{cursor:'pointer'}}>{p.name}</span>}</td>
                  <td style={{padding:'8px 10px'}}>{editing===p.id+'-age'?<input autoFocus defaultValue={p.age} onBlur={e=>{saveField(p.id,'age',e.target.value);setEditing(null);}} style={{...inputSm,padding:'2px 4px',width:50}}/>:<span onClick={()=>setEditing(p.id+'-age')} style={{cursor:'pointer'}}>{p.age}</span>}</td>
                  <td style={{padding:'8px 10px'}}><span style={{padding:'2px 8px',borderRadius:20,fontSize:10,fontWeight:700,...genderColor(p.gender)}}>{p.gender||'—'}</span></td>
                  <td style={{padding:'8px 10px'}}>{editing===p.id+'-phone'?<input autoFocus defaultValue={p.phone} onBlur={e=>{saveField(p.id,'phone',e.target.value);setEditing(null);}} style={{...inputSm,padding:'2px 4px'}}/>:<span onClick={()=>setEditing(p.id+'-phone')} style={{cursor:'pointer'}}>{p.phone}</span>}</td>
                  <td style={{padding:'8px 10px'}}><span style={{background:'var(--teal-m)',color:'var(--teal-d)',borderRadius:20,padding:'2px 8px',fontSize:11,fontWeight:700}}>{visitCount(p.id)}</span></td>
                  <td style={{padding:'8px 10px',textAlign:'right'}}><RowMenu onMerge={()=>toggleMerge(p.id)} onDelete={()=>delPatient(p.id)} visitCount={visitCount(p.id)}/></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <p style={{fontSize:11,color:'var(--muted)',marginTop:8}}>Tap Name/Age/Phone to edit. Use ⋯ on a row to select it for merge or delete it.</p>
    </div>
  );
}
window.DirectoryScreen=DirectoryScreen;
