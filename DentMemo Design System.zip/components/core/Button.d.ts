import * as React from "react";
export interface ButtonProps{
  /** Visual style */
  variant?: "primary"|"secondary"|"success"|"danger";
  /** Compact vs default sizing */
  size?: "md"|"sm";
  /** Optional leading icon/emoji */
  icon?: React.ReactNode;
  children?: React.ReactNode;
  onClick?: () => void;
  disabled?: boolean;
  type?: "button"|"submit";
}
export function Button(props: ButtonProps): JSX.Element;
