The base surface for every section of the app — white, 1.5px border, 14px radius, soft shadow.

```jsx
<Card title="Top Treatments"><TreatmentList/></Card>
<Card padded={false}><Table .../></Card>
```
