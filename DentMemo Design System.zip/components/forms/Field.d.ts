import * as React from "react";
export interface FieldOption{ value: string; label: string; }
export interface FieldProps{
  label?: string;
  type?: "text"|"number"|"date"|"tel"|"select"|"textarea";
  value?: string;
  onChange?: (e: React.ChangeEvent<any>) => void;
  /** Required when type="select" */
  options?: FieldOption[];
  placeholder?: string;
  required?: boolean;
  /** Span the full width of a form-grid row */
  full?: boolean;
}
export function Field(props: FieldProps): JSX.Element;
