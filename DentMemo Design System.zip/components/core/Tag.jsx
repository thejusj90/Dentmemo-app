import React from "react";
export function Tag({children,onRemove}){
  return React.createElement("span",{style:{display:"inline-flex",alignItems:"center",gap:"4px",background:"var(--teal-l)",border:"1px solid var(--teal-m)",borderRadius:"20px",padding:"3px 9px",fontSize:"11px",color:"var(--teal-d)",fontFamily:"var(--font-sans)"}},children,onRemove?React.createElement("span",{onClick:onRemove,style:{cursor:"pointer",color:"var(--red)",fontSize:"13px",fontWeight:700,lineHeight:1}},"×"):null);
}
