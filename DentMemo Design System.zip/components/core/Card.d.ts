import * as React from "react";
export interface CardProps{
  /** Optional header title; omit for a plain body-only card */
  title?: string;
  /** Node rendered right-aligned in the header, e.g. tabs or a button */
  headerRight?: React.ReactNode;
  children?: React.ReactNode;
  /** Set false to remove body padding (e.g. for a table that manages its own) */
  padded?: boolean;
}
export function Card(props: CardProps): JSX.Element;
