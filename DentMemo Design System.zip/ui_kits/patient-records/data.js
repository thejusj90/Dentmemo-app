window.SEED_TREATMENTS=["Consult","Cleaning","Extraction","RCT","Composite Filling","Crown Cementation","GIC Filling","Scaling"];
window.SEED_CONSULTANTS=["Dr. Blessin","Dr. Rao","Dr. Iyer"];
window.SEED_PATIENTS=[
{id:1,pid:"PT-04821",name:"Aditi Rao",age:34,gender:"F",phone:"9812340021"},
{id:2,pid:"PT-01102",name:"Karan Shah",age:41,gender:"M",phone:"9900112233"},
{id:3,pid:"PT-03390",name:"Meera Nair",age:27,gender:"F",phone:"9845098450"},
{id:4,pid:"PT-02207",name:"Rohit Sen",age:52,gender:"M",phone:"9988776655"},
{id:5,pid:"PT-05512",name:"Aisha Khan",age:19,gender:"F",phone:"9765432109"},
{id:6,pid:"PT-00931",name:"Vikram Joshi",age:63,gender:"M",phone:"9123456780"},
{id:7,pid:"PT-04013",name:"Priya Menon",age:29,gender:"F",phone:"9871234560"},
{id:8,pid:"PT-02650",name:"Arjun Nair",age:8,gender:"M",phone:"9012345678"}
];
window.SEED_VISITS=[
{id:1,patientId:1,date:"2026-06-02",diagnosis:"Dental caries #26",treatment:"Composite Filling",consultant:"Dr. Blessin",drFees:800,clinicShare:400,labCost:0,remarks:""},
{id:2,patientId:1,date:"2026-07-10",diagnosis:"Routine check",treatment:"Cleaning",consultant:"Dr. Rao",drFees:600,clinicShare:300,labCost:0,remarks:""},
{id:3,patientId:2,date:"2026-05-21",diagnosis:"Impacted molar",treatment:"Extraction",consultant:"Dr. Blessin",drFees:1500,clinicShare:600,labCost:0,remarks:"Advised soft diet"},
{id:4,patientId:3,date:"2026-07-01",diagnosis:"Pulpitis #14",treatment:"RCT",consultant:"Dr. Iyer",drFees:3500,clinicShare:1200,labCost:400,remarks:""},
{id:5,patientId:3,date:"2026-07-22",diagnosis:"RCT follow-up",treatment:"Crown Cementation",consultant:"Dr. Iyer",drFees:2800,clinicShare:900,labCost:1200,remarks:""},
{id:6,patientId:4,date:"2026-04-14",diagnosis:"Gum sensitivity",treatment:"Scaling",consultant:"Dr. Rao",drFees:700,clinicShare:350,labCost:0,remarks:""},
{id:7,patientId:5,date:"2026-07-28",diagnosis:"Consult only",treatment:"Consult",consultant:"Dr. Blessin",drFees:200,clinicShare:100,labCost:0,remarks:""},
{id:8,patientId:6,date:"2026-03-09",diagnosis:"Denture check",treatment:"Consult",consultant:"Dr. Rao",drFees:200,clinicShare:100,labCost:0,remarks:""},
{id:9,patientId:7,date:"2026-06-18",diagnosis:"Cavity #36",treatment:"GIC Filling",consultant:"Dr. Iyer",drFees:900,clinicShare:400,labCost:0,remarks:""},
{id:10,patientId:8,date:"2026-07-05",diagnosis:"Baby tooth extraction",treatment:"Extraction",consultant:"Dr. Blessin",drFees:500,clinicShare:250,labCost:0,remarks:""},
{id:11,patientId:2,date:"2026-07-30",diagnosis:"Post-extraction check",treatment:"Consult",consultant:"Dr. Blessin",drFees:200,clinicShare:100,labCost:0,remarks:""},
{id:12,patientId:5,date:"2026-07-30",diagnosis:"Cleaning",treatment:"Cleaning",consultant:"Dr. Rao",drFees:600,clinicShare:300,labCost:0,remarks:""}
];
