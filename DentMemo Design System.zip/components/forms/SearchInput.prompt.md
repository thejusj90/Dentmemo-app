Pill-rounded search bar with a leading glyph icon and a floating suggestions list — the main entry point on the Search tab and the patient-name lookup in Add Visit.

```jsx
<SearchInput value={q} onChange={e=>setQ(e.target.value)} suggestions={matches} onSelect={goToPatient}/>
```
