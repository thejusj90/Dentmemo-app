import React from "react";
export function Avatar({name="",gender="X",size=36}){
  const initials=(name||"?").split(" ").map(w=>w[0]).join("").slice(0,2).toUpperCase();
  const map={M:{background:"var(--blue-l)",color:"var(--blue)"},F:{background:"var(--pink-l)",color:"var(--pink)"},X:{background:"var(--border)",color:"var(--muted)"}};
  const s=map[gender]||map.X;
  return React.createElement("div",{style:{width:size,height:size,borderRadius:"50%",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:800,flexShrink:0,fontFamily:"var(--font-sans)",fontSize:size*0.38,...s}},initials);
}
