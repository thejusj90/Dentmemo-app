import * as React from "react";
export interface PillProps{
  value: React.ReactNode;
  label: string;
  tone?: "teal"|"green"|"purple";
}
export function Pill(props: PillProps): JSX.Element;
