function OverviewScreen({patients,visits,doctorMode}){
  const {fmtA}=window.dmHelpers;
  const [period,setPeriod]=React.useState('all');
  const [selMonth,setSelMonth]=React.useState(null);
  const [tab,setTab]=React.useState('treatments');
  if(!doctorMode)return <div style={{textAlign:'center',padding:'40px 20px',color:'var(--muted)'}}><div style={{fontSize:40,marginBottom:10}}>🔒</div><p>Overview is doctor-only. Unlock Doctor Mode to view clinic stats.</p></div>;

  const now=new Date('2026-07-31');
  const cutoff={today:1,week:7,month:31,all:99999}[period];
  const inRange=v=>{
    const d=new Date(v.date);
    return (now-d)/86400000<=cutoff;
  };
  const rangeVisits=visits.filter(inRange);
  const totalRevenue=rangeVisits.reduce((s,v)=>s+(+v.drFees||0)+(+v.clinicShare||0),0);
  const prevRangeVisits=visits.filter(v=>{const d=new Date(v.date);const diff=(now-d)/86400000;return diff>cutoff&&diff<=cutoff*2;});
  const trend=prevRangeVisits.length?Math.round((rangeVisits.length-prevRangeVisits.length)/prevRangeVisits.length*100):null;

  const byMonth={};
  visits.forEach(v=>{const m=v.date.slice(0,7);byMonth[m]=(byMonth[m]||0)+1;});
  const months=Object.keys(byMonth).sort();
  const max=Math.max(1,...months.map(m=>byMonth[m]));
  const byTreatment={};
  rangeVisits.forEach(v=>{byTreatment[v.treatment]=(byTreatment[v.treatment]||0)+1;});
  const topTreatments=Object.entries(byTreatment).sort((a,b)=>b[1]-a[1]).slice(0,6);
  const maxT=Math.max(1,...topTreatments.map(t=>t[1]));
  const byCons={};
  rangeVisits.forEach(v=>{byCons[v.consultant]=(byCons[v.consultant]||0)+1;});
  const topCons=Object.entries(byCons).sort((a,b)=>b[1]-a[1]);
  const maxC=Math.max(1,...topCons.map(c=>c[1]));
  const palette=['var(--teal)','var(--purple)','var(--sky)','var(--green)','var(--amber)','#94a3b8'];

  const Stat=({icon,val,label,color,sub})=>(
    <div style={{background:'#fff',border:'1.5px solid var(--border)',borderRadius:14,padding:'14px',boxShadow:'var(--shadow)'}}>
      <div style={{display:'flex',alignItems:'center',justifyContent:'space-between',marginBottom:6}}>
        <span style={{fontSize:18}}>{icon}</span>
        {sub!=null?<span style={{fontSize:10,fontWeight:700,color:sub>=0?'var(--green)':'var(--red)'}}>{sub>=0?'▲':'▼'} {Math.abs(sub)}%</span>:null}
      </div>
      <div style={{fontSize:22,fontWeight:800,color}}>{val}</div>
      <div style={{fontSize:11,color:'var(--muted)',marginTop:2}}>{label}</div>
    </div>
  );

  return (
    <div>
      <div style={{position:'relative',marginBottom:14,padding:5,borderRadius:20,display:'inline-flex',gap:2,overflowX:'auto',maxWidth:'100%',background:'linear-gradient(135deg,rgba(219,232,255,.55),rgba(255,255,255,.35))',backdropFilter:'blur(16px) saturate(180%)',WebkitBackdropFilter:'blur(16px) saturate(180%)',border:'1px solid rgba(255,255,255,.6)',boxShadow:'0 4px 20px rgba(13,27,61,.10), inset 0 1px 0 rgba(255,255,255,.9)'}}>
        {[['today','Today'],['week','This Week'],['month','This Month'],['all','All Time']].map(([k,l])=>(
          <button key={k} onClick={()=>setPeriod(k)} style={{whiteSpace:'nowrap',padding:'7px 16px',borderRadius:16,fontSize:12,fontWeight:600,cursor:'pointer',border:period===k?'1px solid rgba(255,255,255,.7)':'none',background:period===k?'rgba(255,255,255,.75)':'transparent',backdropFilter:period===k?'blur(6px)':'none',color:period===k?'var(--teal-d)':'var(--muted)',boxShadow:period===k?'0 2px 8px rgba(13,27,61,.12), inset 0 1px 0 rgba(255,255,255,.9)':'none',transition:'all .2s ease'}}>{l}</button>
        ))}
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(130px,1fr))',gap:10,marginBottom:14}}>
        <Stat icon="🧑‍🤝‍🧑" val={patients.length} label="Patients" color="var(--teal)"/>
        <Stat icon="🗓️" val={rangeVisits.length} label="Visits" color="var(--teal)" sub={trend}/>
        <Stat icon="💰" val={fmtA(totalRevenue)} label="Collected" color="var(--green)"/>
        <Stat icon="🦷" val={Object.keys(byCons).length} label="Consultants" color="var(--purple)"/>
      </div>
      <div style={{background:'#fff',border:'1.5px solid var(--border)',borderRadius:14,boxShadow:'var(--shadow)',padding:14,marginBottom:12}}>
        <div style={{display:'flex',justifyContent:'space-between',alignItems:'baseline',marginBottom:12}}>
          <div style={{fontWeight:700,fontSize:14}}>Monthly Visits</div>
          {selMonth?<div style={{fontSize:12,color:'var(--teal)',fontWeight:700}}>{selMonth}: {byMonth[selMonth]} visits</div>:<div style={{fontSize:11,color:'var(--muted)'}}>Tap a bar for detail</div>}
        </div>
        <div style={{display:'flex',alignItems:'flex-end',gap:6,height:120}}>
          {months.map(m=>(
            <div key={m} onClick={()=>setSelMonth(m===selMonth?null:m)} style={{flex:1,display:'flex',flexDirection:'column',alignItems:'center',gap:4,cursor:'pointer',minWidth:22}}>
              <div style={{width:'100%',background:m===selMonth?'var(--teal-d)':'var(--teal)',borderRadius:'6px 6px 2px 2px',height:(byMonth[m]/max*94)+'px',minHeight:4,transition:'background .15s'}}/>
              <span style={{fontSize:10,color:m===selMonth?'var(--teal-d)':'var(--muted)',fontWeight:m===selMonth?700:400}}>{m.slice(5)}</span>
            </div>
          ))}
        </div>
      </div>
      <div style={{background:'#fff',border:'1.5px solid var(--border)',borderRadius:14,boxShadow:'var(--shadow)',overflow:'hidden'}}>
        <div style={{display:'flex',borderBottom:'1px solid var(--border)'}}>
          <button onClick={()=>setTab('treatments')} style={{flex:1,padding:'12px',fontSize:13,fontWeight:700,border:'none',background:tab==='treatments'?'var(--teal-l)':'#fff',color:tab==='treatments'?'var(--teal-d)':'var(--muted)',cursor:'pointer',borderBottom:tab==='treatments'?'2px solid var(--teal)':'none'}}>Top Treatments</button>
          <button onClick={()=>setTab('consultants')} style={{flex:1,padding:'12px',fontSize:13,fontWeight:700,border:'none',background:tab==='consultants'?'var(--teal-l)':'#fff',color:tab==='consultants'?'var(--teal-d)':'var(--muted)',cursor:'pointer',borderBottom:tab==='consultants'?'2px solid var(--teal)':'none'}}>Consultants</button>
        </div>
        <div style={{padding:14}}>
          {tab==='treatments'?(topTreatments.length===0?<div style={{color:'var(--muted)',fontSize:12,textAlign:'center',padding:10}}>No visits in this period</div>:topTreatments.map(([t,n],i)=>(
            <div key={t} style={{display:'flex',alignItems:'center',gap:10,marginBottom:10}}>
              <span style={{width:8,height:8,borderRadius:'50%',background:palette[i%palette.length],flexShrink:0}}/>
              <div style={{flex:1}}>
                <div style={{display:'flex',justifyContent:'space-between',fontSize:12,marginBottom:3}}><span>{t}</span><span style={{color:'var(--muted)',fontWeight:700}}>{n}</span></div>
                <div style={{background:'var(--border)',borderRadius:3,height:5}}><div style={{background:palette[i%palette.length],borderRadius:3,height:5,width:(n/maxT*100)+'%',transition:'width .3s'}}/></div>
              </div>
            </div>
          ))):(topCons.length===0?<div style={{color:'var(--muted)',fontSize:12,textAlign:'center',padding:10}}>No visits in this period</div>:topCons.map(([c,n],i)=>(
            <div key={c} style={{display:'flex',alignItems:'center',gap:10,marginBottom:10}}>
              <span style={{width:8,height:8,borderRadius:'50%',background:palette[i%palette.length],flexShrink:0}}/>
              <div style={{flex:1}}>
                <div style={{display:'flex',justifyContent:'space-between',fontSize:12,marginBottom:3}}><span>{c}</span><span style={{color:'var(--muted)',fontWeight:700}}>{n}</span></div>
                <div style={{background:'var(--border)',borderRadius:3,height:5}}><div style={{background:palette[i%palette.length],borderRadius:3,height:5,width:(n/maxC*100)+'%',transition:'width .3s'}}/></div>
              </div>
            </div>
          )))}
        </div>
      </div>
    </div>
  );
}
window.OverviewScreen=OverviewScreen;
