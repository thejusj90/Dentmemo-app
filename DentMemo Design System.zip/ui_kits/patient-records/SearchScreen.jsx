const inputSm={padding:'9px 11px',border:'1.5px solid var(--border)',borderRadius:10,fontSize:13,fontFamily:'inherit',outline:'none',width:'100%'};
const labelSm={fontSize:10,fontWeight:700,color:'var(--muted)',letterSpacing:'.3px',textTransform:'uppercase',display:'block',marginBottom:4};
function fmtA(n){return n&&+n>0?'₹'+(+n).toLocaleString('en-IN'):'—';}
function fmtD(d){if(!d)return'—';const p=d.split('-');return p[2]+'/'+p[1]+'/'+p[0];}
function initials(n){return (n||'?').split(' ').map(w=>w[0]).join('').slice(0,2).toUpperCase();}
function genderColor(g){return g==='M'?{background:'#dbeafe',color:'#1d4ed8'}:g==='F'?{background:'#fce7f3',color:'#be185d'}:{background:'var(--border)',color:'var(--muted)'};}

function SearchScreen({patients,visits,doctorMode,onGoAddVisit}){
  const [q,setQ]=React.useState('');
  const [selected,setSelected]=React.useState(null);
  const matches=q.trim()?patients.filter(p=>p.name.toLowerCase().includes(q.toLowerCase())||p.phone.includes(q)||p.pid.toLowerCase().includes(q.toLowerCase())):[];
  const patientVisits=selected?visits.filter(v=>v.patientId===selected.id).sort((a,b)=>b.date.localeCompare(a.date)):[];
  const total=patientVisits.reduce((s,v)=>s+(+v.drFees||0)+(+v.clinicShare||0),0);

  if(selected){
    return (
      <div>
        <button onClick={()=>setSelected(null)} style={{display:'inline-flex',alignItems:'center',gap:5,color:'var(--muted)',fontSize:12,cursor:'pointer',border:'1.5px solid var(--border)',borderRadius:8,padding:'5px 10px',background:'none',marginBottom:10}}>← Back</button>
        <div style={{background:'#fff',border:'1.5px solid var(--border)',borderRadius:14,boxShadow:'var(--shadow)',padding:16,marginBottom:12,display:'flex',gap:14,alignItems:'center'}}>
          <div style={{width:52,height:52,borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',fontWeight:800,...genderColor(selected.gender)}}>{initials(selected.name)}</div>
          <div style={{flex:1}}>
            <div style={{fontWeight:700,fontSize:15}}>{selected.name}</div>
            <div style={{fontSize:12,color:'var(--muted)'}}>{selected.pid} · {selected.gender==='M'?'Male':selected.gender==='F'?'Female':'—'} · {selected.age} yrs · {selected.phone}</div>
          </div>
          <div style={{display:'flex',gap:8}}>
            <div style={{background:'var(--bg)',border:'1.5px solid var(--border)',borderRadius:10,padding:'8px 12px',textAlign:'center',minWidth:70}}><div style={{fontSize:16,fontWeight:800,color:'var(--teal)'}}>{patientVisits.length}</div><div style={{fontSize:10,color:'var(--muted)'}}>Visits</div></div>
            {doctorMode?<div style={{background:'var(--bg)',border:'1.5px solid var(--border)',borderRadius:10,padding:'8px 12px',textAlign:'center',minWidth:70}}><div style={{fontSize:16,fontWeight:800,color:'var(--green)'}}>{fmtA(total)}</div><div style={{fontSize:10,color:'var(--muted)'}}>Total</div></div>:null}
          </div>
        </div>
        <div style={{background:'#fff',border:'1.5px solid var(--border)',borderRadius:14,boxShadow:'var(--shadow)',overflow:'hidden'}}>
          <div style={{padding:'12px 16px',borderBottom:'1px solid var(--border)',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
            <div style={{fontWeight:700,fontSize:14}}>Visit History</div>
            <button onClick={()=>onGoAddVisit(selected)} style={{padding:'5px 10px',borderRadius:7,fontSize:11,fontWeight:700,cursor:'pointer',border:'none',background:'var(--teal)',color:'#fff'}}>+ Add Visit</button>
          </div>
          <div style={{overflowX:'auto'}}>
            <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
              <thead><tr>
                <th style={{padding:'8px 10px',textAlign:'left',fontSize:10,color:'var(--muted)',textTransform:'uppercase',background:'var(--bg)'}}>Date</th>
                <th style={{padding:'8px 10px',textAlign:'left',fontSize:10,color:'var(--muted)',textTransform:'uppercase',background:'var(--bg)'}}>Treatment</th>
                <th style={{padding:'8px 10px',textAlign:'left',fontSize:10,color:'var(--muted)',textTransform:'uppercase',background:'var(--bg)'}}>Diagnosis</th>
                <th style={{padding:'8px 10px',textAlign:'left',fontSize:10,color:'var(--muted)',textTransform:'uppercase',background:'var(--bg)'}}>Consultant</th>
                {doctorMode?<th style={{padding:'8px 10px',textAlign:'right',fontSize:10,color:'var(--muted)',textTransform:'uppercase',background:'var(--bg)'}}>Fees</th>:null}
              </tr></thead>
              <tbody>
                {patientVisits.length===0?<tr><td colSpan={5} style={{padding:20,textAlign:'center',color:'var(--muted)'}}>No visits yet</td></tr>:patientVisits.map(v=>(
                  <tr key={v.id} style={{borderBottom:'1px solid var(--border)'}}>
                    <td style={{padding:'8px 10px',color:'var(--muted)',whiteSpace:'nowrap'}}>{fmtD(v.date)}</td>
                    <td style={{padding:'8px 10px'}}>{v.treatment||'—'}</td>
                    <td style={{padding:'8px 10px'}}>{v.diagnosis||'—'}</td>
                    <td style={{padding:'8px 10px'}}>{v.consultant||'—'}</td>
                    {doctorMode?<td style={{padding:'8px 10px',textAlign:'right',fontWeight:700,color:'var(--green)'}}>{fmtA((+v.drFees||0)+(+v.clinicShare||0))}</td>:null}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  }
  return (
    <div>
      <div style={{position:'relative',marginBottom:12}}>
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" style={{position:'absolute',left:12,top:'50%',transform:'translateY(-50%)',color:'var(--muted)'}}><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
        <input value={q} onChange={e=>setQ(e.target.value)} placeholder="Search by name, phone, or Patient ID…" style={{width:'100%',padding:'12px 12px 12px 40px',border:'1.5px solid var(--border)',borderRadius:12,fontSize:14,background:'#fff',outline:'none'}}/>
        {matches.length>0?(
          <div style={{position:'absolute',top:'calc(100% + 4px)',left:0,right:0,background:'#fff',border:'1.5px solid var(--border)',borderRadius:12,boxShadow:'var(--shadow)',zIndex:50,maxHeight:260,overflowY:'auto'}}>
            {matches.map(p=>(
              <div key={p.id} onClick={()=>{setSelected(p);setQ('');}} style={{padding:'10px 14px',cursor:'pointer',borderBottom:'1px solid var(--border)'}}>
                <div style={{fontWeight:600,fontSize:13}}>{p.name}</div>
                <div style={{fontSize:11,color:'var(--muted)'}}>{p.pid} · {p.phone}</div>
              </div>
            ))}
          </div>
        ):null}
      </div>
      {!q?(
        <div>
          <div style={{fontSize:11,fontWeight:700,color:'var(--muted)',textTransform:'uppercase',marginBottom:8}}>Recent Patients</div>
          <div style={{display:'flex',flexDirection:'column',gap:6}}>
            {patients.slice(0,4).map(p=>(
              <div key={p.id} onClick={()=>setSelected(p)} style={{cursor:'pointer',display:'flex',alignItems:'center',gap:10,background:'#fff',border:'1.5px solid var(--border)',borderRadius:10,padding:'8px 12px'}}>
                <div style={{width:32,height:32,borderRadius:'50%',display:'flex',alignItems:'center',justifyContent:'center',fontWeight:800,fontSize:12,...genderColor(p.gender)}}>{initials(p.name)}</div>
                <div style={{flex:1}}><div style={{fontSize:13,fontWeight:600}}>{p.name}</div><div style={{fontSize:11,color:'var(--muted)'}}>{p.pid}</div></div>
              </div>
            ))}
          </div>
        </div>
      ):null}
    </div>
  );
}
window.SearchScreen=SearchScreen;
window.dmHelpers={inputSm,labelSm,fmtA,fmtD,initials,genderColor};
