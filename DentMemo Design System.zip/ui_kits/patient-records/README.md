# Patient Records — Onboarding

Click-through recreation of the fixed onboarding flow, replacing the old screen that showed "New? We'll set up your clinic" and "Enter PIN to unlock" simultaneously.

**New clinic:** Continue with Google → Doctor + clinic name → optional logo → create Doctor PIN → starter treatments → Home.
**Returning:** Continue with Google → Home directly. The PIN pad only appears when unlocking Doctor Mode from Home (🔒 Unlock Doctor, demo PIN `1234`).

Use the top-right toggle to preview either path. No other app flows (assistant-mode messaging, patient dedup, follow-ups, etc.) were changed — this kit covers onboarding only.
