Labeled form control (input/select/textarea in one) with the app's uppercase micro-label above it. Drop several into a CSS grid (`repeat(auto-fit,minmax(160px,1fr))`) to build a form-grid like Add Visit or Edit Visit.

```jsx
<Field label="Full Name" required value={name} onChange={e=>setName(e.target.value)}/>
<Field label="Gender" type="select" options={[{value:'M',label:'Male'},{value:'F',label:'Female'}]}/>
<Field label="Remarks" type="textarea" full/>
```
