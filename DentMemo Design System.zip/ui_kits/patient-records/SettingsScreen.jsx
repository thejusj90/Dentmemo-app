function SettingsScreen({clinicName,setClinicName,logo,setLogo,treatments,setTreatments,consultants,setConsultants,onLockAssistant}){
  const {inputSm}=window.dmHelpers;
  const [newT,setNewT]=React.useState('');
  const [newC,setNewC]=React.useState('');
  const fileRef=React.useRef(null);
  const onFile=e=>{
    const f=e.target.files[0];if(!f)return;
    const r=new FileReader();
    r.onload=ev=>setLogo(ev.target.result);
    r.readAsDataURL(f);
  };
  const Section=({title,children})=>(
    <div style={{marginBottom:18}}>
      <h3 style={{fontSize:11,fontWeight:700,color:'var(--muted)',textTransform:'uppercase',letterSpacing:.5,marginBottom:8,paddingBottom:5,borderBottom:'1px solid var(--border)'}}>{title}</h3>
      {children}
    </div>
  );
  return (
    <div style={{background:'#fff',border:'1.5px solid var(--border)',borderRadius:14,boxShadow:'var(--shadow)',padding:16}}>
      <Section title="Clinic Branding">
        <div style={{display:'flex',gap:8,marginBottom:12}}>
          <input value={clinicName} onChange={e=>setClinicName(e.target.value)} placeholder="Clinic name" style={{...inputSm,flex:1}}/>
        </div>
        <div style={{display:'flex',gap:16,alignItems:'center'}}>
          {logo?<img src={logo} style={{width:56,height:56,objectFit:'contain',borderRadius:8,background:'var(--bg)',border:'1px solid var(--border)'}}/>:null}
          <div>
            <label style={{fontSize:10,fontWeight:700,color:'var(--muted)',letterSpacing:'.3px',textTransform:'uppercase',display:'block',marginBottom:4}}>Clinic Logo</label>
            <input ref={fileRef} type="file" accept="image/*" onChange={onFile}/>
          </div>
        </div>
      </Section>
      <Section title="Treatments">
        <div style={{display:'flex',flexWrap:'wrap',gap:5,marginBottom:8}}>
          {treatments.map(t=>(
            <span key={t} style={{display:'inline-flex',alignItems:'center',gap:4,background:'var(--teal-l)',border:'1px solid var(--teal-m)',borderRadius:20,padding:'3px 9px',fontSize:11,color:'var(--teal-d)'}}>{t}<span onClick={()=>setTreatments(treatments.filter(x=>x!==t))} style={{cursor:'pointer',color:'var(--red)',fontWeight:700}}>×</span></span>
          ))}
        </div>
        <div style={{display:'flex',gap:6}}>
          <input value={newT} onChange={e=>setNewT(e.target.value)} placeholder="Add new treatment…" style={{...inputSm,flex:1}}/>
          <button onClick={()=>{if(newT){setTreatments([...treatments,newT]);setNewT('');}}} style={{padding:'6px 12px',borderRadius:8,fontSize:12,fontWeight:700,border:'none',background:'var(--teal)',color:'#fff',cursor:'pointer'}}>+ Add</button>
        </div>
      </Section>
      <Section title="Consultants">
        <div style={{display:'flex',flexWrap:'wrap',gap:5,marginBottom:8}}>
          {consultants.map(c=>(
            <span key={c} style={{display:'inline-flex',alignItems:'center',gap:4,background:'var(--teal-l)',border:'1px solid var(--teal-m)',borderRadius:20,padding:'3px 9px',fontSize:11,color:'var(--teal-d)'}}>{c}<span onClick={()=>setConsultants(consultants.filter(x=>x!==c))} style={{cursor:'pointer',color:'var(--red)',fontWeight:700}}>×</span></span>
          ))}
        </div>
        <div style={{display:'flex',gap:6}}>
          <input value={newC} onChange={e=>setNewC(e.target.value)} placeholder="Add new consultant…" style={{...inputSm,flex:1}}/>
          <button onClick={()=>{if(newC){setConsultants([...consultants,newC]);setNewC('');}}} style={{padding:'6px 12px',borderRadius:8,fontSize:12,fontWeight:700,border:'none',background:'var(--teal)',color:'#fff',cursor:'pointer'}}>+ Add</button>
        </div>
      </Section>
      <Section title="Access">
        <button onClick={onLockAssistant} style={{padding:'5px 10px',borderRadius:7,fontSize:11,fontWeight:700,cursor:'pointer',border:'1.5px solid #fecaca',background:'#fee2e2',color:'var(--red)'}}>🔒 Lock to Assistant Mode</button>
      </Section>
    </div>
  );
}
window.SettingsScreen=SettingsScreen;
