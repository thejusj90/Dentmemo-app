Primary action button in four tones, used for save/cancel/delete/add flows throughout the patient-records app.

```jsx
<Button variant="primary">Save Visit</Button>
<Button variant="danger" size="sm">Delete Visit</Button>
```

Variants: `primary` (teal, main CTA), `secondary` (bordered neutral, cancel), `success` (green, confirm/save), `danger` (red-tinted, destructive). `size="sm"` is used inline in tables/toolbars.
