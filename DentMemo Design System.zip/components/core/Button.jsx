import React from "react";
export function Button({variant="primary",size="md",icon,children,onClick,disabled,type="button"}){
  const bg={primary:{background:"var(--teal)",color:"#fff"},secondary:{background:"var(--bg)",color:"var(--ink)",border:"1.5px solid var(--border)"},success:{background:"var(--green)",color:"#fff"},danger:{background:"#fee2e2",color:"var(--red)",border:"1.5px solid #fecaca"}}[variant]||{};
  const sz=size==="sm"?{padding:"5px 10px",fontSize:"11px",borderRadius:"7px"}:{padding:"9px 16px",fontSize:"13px",borderRadius:"10px"};
  return React.createElement("button",{type,onClick,disabled,style:{...sz,...bg,fontWeight:700,cursor:disabled?"default":"pointer",border:bg.border||"none",display:"inline-flex",alignItems:"center",gap:"6px",fontFamily:"var(--font-sans)",opacity:disabled?.6:1}},icon?React.createElement("span",null,icon):null,children);
}
