Circular initials avatar, color-coded by gender (blue/pink/neutral), used in search results and patient headers.

```jsx
<Avatar name="Aditi Rao" gender="F" size={48}/>
```
