import * as React from "react";
export interface AvatarProps{
  /** Full name — initials are derived automatically */
  name?: string;
  gender?: "M"|"F"|"X";
  /** Diameter in px */
  size?: number;
}
export function Avatar(props: AvatarProps): JSX.Element;
