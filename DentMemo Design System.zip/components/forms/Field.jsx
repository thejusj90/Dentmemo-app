import React from "react";
export function Field({label,type="text",value,onChange,options,placeholder,required,full}){
  const base={padding:"9px 11px",border:"1.5px solid var(--border)",borderRadius:"10px",fontSize:"13px",color:"var(--ink)",background:"#fff",outline:"none",fontFamily:"var(--font-sans)",width:"100%"};
  let control;
  if(type==="select"){
    control=React.createElement("select",{value,onChange,style:{...base,cursor:"pointer"}},(options||[]).map(o=>React.createElement("option",{key:o.value,value:o.value},o.label)));
  }else if(type==="textarea"){
    control=React.createElement("textarea",{value,onChange,placeholder,style:{...base,resize:"vertical",minHeight:"60px"}});
  }else{
    control=React.createElement("input",{type,value,onChange,placeholder,style:base});
  }
  return React.createElement("div",{style:{display:"flex",flexDirection:"column",gap:"4px",gridColumn:full?"1/-1":undefined}},
    label?React.createElement("label",{style:{fontSize:"10px",fontWeight:700,color:"var(--muted)",letterSpacing:".3px",textTransform:"uppercase"}},label,required?" *":""):null,
    control);
}
