import React from "react";
export function Pill({value,label,tone="teal"}){
  const color={teal:"var(--teal)",green:"var(--green)",purple:"var(--purple)"}[tone]||"var(--teal)";
  return React.createElement("div",{style:{background:"var(--bg)",border:"1.5px solid var(--border)",borderRadius:"10px",padding:"8px 12px",textAlign:"center",minWidth:"80px",fontFamily:"var(--font-sans)"}},
    React.createElement("div",{style:{fontSize:"16px",fontWeight:800,color}},value),
    React.createElement("div",{style:{fontSize:"10px",color:"var(--muted)",marginTop:"2px"}},label));
}
