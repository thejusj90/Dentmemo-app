# DentMemo Design System

Design system for **DentMemo** — a multi-tenant dental-clinic patient-records web app. Built from the source codebase at [thejusj90/Dr-Blessin-Mathew-Dental-Studio](https://github.com/thejusj90/Dr-Blessin-Mathew-Dental-Studio) (see `github.md`). Explore that repo further for backend/auth/data-model detail this design system doesn't cover.

## Index
- `styles.css` + `tokens/` — color, type, spacing tokens
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand)
- `components/` — reusable UI primitives (below)
- `assets/` — clinic logo (full lockup + icon-only mark)
- `ui_kits/patient-records/` — click-through recreation of the app

## Components
- **core/** — Button, Badge, Avatar, Tag, Pill, Card, EmptyState
- **forms/** — Field (input/select/textarea), SearchInput

More component groups (navigation, feedback, data display, auth) are in progress.

## Content fundamentals
Utilitarian, clinical-staff tone — short imperative labels ("+ Add", "✓ Save Visit", "Search by name, phone, or Patient ID…"), no marketing voice. Second person avoided; UI addresses the task, not the user. Sparse functional emoji as icons (🔍 ✏️ 📝 ⚙ 🔒 ✓ ✕ ⬇), never decorative. Currency in ₹, Indian numeral grouping.

## Visual foundations
Future Blue (#2563FF) accent with a Deep Navy (#0D1B3D) strong/hover tone, on white cards over an Off White (#FAFBFD) page. One signature gradient (135deg Future Blue→Deep Navy) reserved for the nav bar only — never buttons or cards. Flat, no illustration/imagery/texture. Cards: 14px radius, 1.5px `--border` (Cool Gray #E6EAF0), soft `--shadow`. Inputs/buttons: 10px radius. Pills/badges/tags: fully rounded. Avatars: circular, gender-tinted (blue/pink/neutral). **Inter** throughout (SemiBold/Bold headings, Regular/Medium body), loaded via Google Fonts. No motion/animation beyond a spinner and toast slide-in.

## Brand update (Aug 2026)
Rebranded from the source app's teal/Segoe-UI look to DentMemo's own guidelines: new tooth+speech-bubble mark (`assets/logo.png` full lockup, `assets/logo-mark.png` icon-only), Future Blue/Deep Navy/Sky Blue/Cool Gray/Charcoal/Off White palette, Inter typeface. Token *names* (`--teal`, `--teal-d`, `--ink`, `--border`, `--bg`…) were kept stable and just repointed to the new hex values, so components didn't need rewriting.

## Iconography
No icon font or SVG icon set — the app uses plain Unicode emoji as functional glyphs, plus one inline multi-color Google "G" SVG (login) and one Feather-style stroke search icon. No PNG/SVG icon library to copy in; keep using emoji + simple stroke SVGs for consistency.

## Sources
- GitHub: https://github.com/thejusj90/Dr-Blessin-Mathew-Dental-Studio (primary source of truth — `app.html`, `DEPLOY_NOTES.md`, `README.md`)
