const inputSm={padding:'9px 11px',border:'1.5px solid var(--border)',borderRadius:10,fontSize:13,fontFamily:'inherit',outline:'none',width:'100%'};
const labelSm={fontSize:10,fontWeight:700,color:'var(--muted)',letterSpacing:'.3px',textTransform:'uppercase',display:'block',marginBottom:4};

function AddVisitScreen({patients,setPatients,treatments,consultants,setVisits,visits,prefill,onSaved}){
  const [f,setF]=React.useState({name:prefill?prefill.name:'',date:'',diagnosis:'',treatment:'',consultant:'',drFees:'',clinicShare:'',labCost:'',remarks:''});
  const [saved,setSaved]=React.useState(false);
  const set=k=>e=>setF({...f,[k]:e.target.value});
  const matches=f.name&&!prefill?patients.filter(p=>p.name.toLowerCase().includes(f.name.toLowerCase())):[];
  const [linked,setLinked]=React.useState(prefill||null);
  const save=()=>{
    let patient=linked||patients.find(p=>p.name.toLowerCase()===f.name.toLowerCase());
    if(!patient){
      const nid=Math.max(0,...patients.map(p=>p.id))+1;
      patient={id:nid,pid:'PT-'+(10000+nid),name:f.name,age:0,gender:'',phone:''};
      setPatients([...patients,patient]);
    }
    const nid=Math.max(0,...visits.map(v=>v.id))+1;
    setVisits([...visits,{id:nid,patientId:patient.id,date:f.date,diagnosis:f.diagnosis,treatment:f.treatment,consultant:f.consultant,drFees:+f.drFees||0,clinicShare:+f.clinicShare||0,labCost:+f.labCost||0,remarks:f.remarks}]);
    setSaved(true);
    setTimeout(()=>onSaved&&onSaved(),900);
  };
  if(saved) return <div style={{textAlign:'center',padding:'40px 20px',color:'var(--green)'}}><div style={{fontSize:40,marginBottom:10}}>✓</div><p style={{fontWeight:700}}>Visit saved</p></div>;
  const patientResolved=linked||patients.find(p=>p.name.toLowerCase()===f.name.toLowerCase());
  return (
    <div style={{background:'#fff',border:'1.5px solid var(--border)',borderRadius:14,boxShadow:'var(--shadow)',padding:16}}>
      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(160px,1fr))',gap:10,marginBottom:14}}>
        <div style={{position:'relative'}}>
          <label style={labelSm}>Patient Name *</label>
          <input style={inputSm} value={f.name} onChange={e=>{setLinked(null);setF({...f,name:e.target.value});}} placeholder="Type to search…" disabled={!!prefill}/>
          {matches.length>0&&!linked?(
            <div style={{position:'absolute',top:'100%',left:0,right:0,background:'#fff',border:'1.5px solid var(--border)',borderRadius:10,boxShadow:'var(--shadow)',zIndex:20}}>
              {matches.map(p=><div key={p.id} onClick={()=>{setLinked(p);setF({...f,name:p.name});}} style={{padding:'8px 12px',cursor:'pointer',fontSize:12,borderBottom:'1px solid var(--border)'}}>{p.name} <span style={{color:'var(--muted)'}}>· {p.pid}</span></div>)}
            </div>
          ):null}
          {!patientResolved&&f.name?<div style={{fontSize:11,color:'var(--amber)',marginTop:4}}>New patient — will be added as "{f.name}" on save</div>:null}
        </div>
        <div><label style={labelSm}>Date *</label><input type="date" style={inputSm} value={f.date} onChange={set('date')}/></div>
        <div style={{gridColumn:'1/-1'}}><label style={labelSm}>Diagnosis / Tooth</label><input style={inputSm} value={f.diagnosis} onChange={set('diagnosis')}/></div>
        <div style={{gridColumn:'1/-1'}}><label style={labelSm}>Treatment</label>
          <select style={inputSm} value={f.treatment} onChange={set('treatment')}><option value="">— Select treatment —</option>{treatments.map(t=><option key={t}>{t}</option>)}</select>
        </div>
        <div><label style={labelSm}>Consultant</label>
          <select style={inputSm} value={f.consultant} onChange={set('consultant')}><option value="">— Select —</option>{consultants.map(c=><option key={c}>{c}</option>)}</select>
        </div>
        <div><label style={labelSm}>Dr Fees (₹)</label><input type="number" style={inputSm} value={f.drFees} onChange={set('drFees')} placeholder="0"/></div>
        <div><label style={labelSm}>Clinic Share (₹)</label><input type="number" style={inputSm} value={f.clinicShare} onChange={set('clinicShare')} placeholder="0"/></div>
        <div><label style={labelSm}>Lab Cost (₹)</label><input type="number" style={inputSm} value={f.labCost} onChange={set('labCost')} placeholder="0"/></div>
        <div style={{gridColumn:'1/-1'}}><label style={labelSm}>Remarks</label><textarea style={{...inputSm,minHeight:60,resize:'vertical'}} value={f.remarks} onChange={set('remarks')}/></div>
      </div>
      <div style={{display:'flex',justifyContent:'flex-end',gap:8}}>
        <button onClick={()=>setF({name:prefill?prefill.name:'',date:'',diagnosis:'',treatment:'',consultant:'',drFees:'',clinicShare:'',labCost:'',remarks:''})} style={{padding:'9px 16px',borderRadius:10,fontSize:13,fontWeight:700,cursor:'pointer',border:'1.5px solid var(--border)',background:'var(--bg)',color:'var(--ink)'}}>Clear</button>
        <button onClick={save} disabled={!f.name||!f.date} style={{padding:'9px 16px',borderRadius:10,fontSize:13,fontWeight:700,cursor:'pointer',border:'none',background:'var(--green)',color:'#fff',opacity:(!f.name||!f.date)?.5:1}}>✓ Save Visit</button>
      </div>
    </div>
  );
}

function HomeShell(props){
  const {clinicName,setClinicName,logo,setLogo,patients,setPatients,visits,setVisits,treatments,setTreatments,consultants,setConsultants,doctorMode,onRequestDoctorMode,onLockAssistant,onLogout}=props;
  const tabs=['Search','+ Visit','Directory','Records'];
  const doctorTabs=['Overview','⚙ Settings'];
  const [active,setActive]=React.useState('Search');
  const [prefill,setPrefill]=React.useState(null);
  const goAddVisit=p=>{setPrefill(p);setActive('+ Visit');};

  return (
    <div style={{minHeight:'100vh',background:'var(--bg)',fontFamily:'var(--font-sans)'}}>
      <nav style={{background:'linear-gradient(135deg,var(--teal),var(--teal-d))',color:'#fff',padding:'0 14px',display:'flex',alignItems:'center',gap:6,height:56,boxShadow:'0 2px 12px rgba(13,148,136,.3)',overflowX:'auto'}}>
        <div style={{display:'flex',alignItems:'center',gap:8,marginRight:'auto'}}>
          <img src={logo||'../../assets/logo-mark.png'} style={{height:32,width:32,objectFit:'contain',background:'#fff',borderRadius:6,padding:2}}/>
          <div><span style={{fontSize:13,fontWeight:800,display:'block'}}>{clinicName||"Dr. Blessin's"}</span></div>
        </div>
        <div style={{display:'flex',gap:2}}>
          {tabs.map(t=><button key={t} onClick={()=>{setActive(t);if(t!=='+ Visit')setPrefill(null);}} style={{padding:'7px 10px',borderRadius:8,fontSize:11,fontWeight:600,border:'none',background:active===t?'rgba(255,255,255,.22)':'none',color:'#fff',cursor:'pointer'}}>{t}</button>)}
          {doctorMode?doctorTabs.map(t=><button key={t} onClick={()=>setActive(t)} style={{padding:'7px 10px',borderRadius:8,fontSize:11,fontWeight:600,border:'none',background:active===t?'rgba(255,255,255,.22)':'none',color:'#fff',cursor:'pointer'}}>{t}</button>):null}
          <button onClick={doctorMode?onLockAssistant:onRequestDoctorMode} style={{padding:'7px 10px',borderRadius:8,fontSize:11,fontWeight:600,border:'none',background:'none',color:'rgba(255,255,255,.85)',cursor:'pointer'}}>{doctorMode?'🔓 Doctor':'🔒 Unlock Doctor'}</button>
          <button onClick={onLogout} style={{padding:'7px 10px',borderRadius:8,fontSize:11,fontWeight:600,border:'none',background:'none',color:'rgba(255,255,255,.7)',cursor:'pointer'}}>Logout</button>
        </div>
      </nav>
      <div style={{padding:14,maxWidth:1200,margin:'0 auto'}}>
        {active==='Search'?<SearchScreen patients={patients} visits={visits} doctorMode={doctorMode} onGoAddVisit={goAddVisit}/>:null}
        {active==='+ Visit'?<AddVisitScreen patients={patients} setPatients={setPatients} treatments={treatments} consultants={consultants} visits={visits} setVisits={setVisits} prefill={prefill} onSaved={()=>{setActive('Search');setPrefill(null);}}/>:null}
        {active==='Directory'?<DirectoryScreen patients={patients} setPatients={setPatients} visits={visits} setVisits={setVisits} treatments={treatments} doctorMode={doctorMode}/>:null}
        {active==='Records'?<RecordsScreen patients={patients} visits={visits} treatments={treatments} consultants={consultants} doctorMode={doctorMode}/>:null}
        {active==='Overview'?<OverviewScreen patients={patients} visits={visits} doctorMode={doctorMode}/>:null}
        {active==='⚙ Settings'?<SettingsScreen clinicName={clinicName} setClinicName={setClinicName} logo={logo} setLogo={setLogo} treatments={treatments} setTreatments={setTreatments} consultants={consultants} setConsultants={setConsultants} onLockAssistant={()=>{onLockAssistant();setActive('Search');}}/>:null}
      </div>
    </div>
  );
}
window.HomeShell=HomeShell;
