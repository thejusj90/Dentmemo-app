/* @ds-bundle: {"format":4,"namespace":"DentMemoDesignSystem_43f866","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"EmptyState","sourcePath":"components/core/EmptyState.jsx"},{"name":"Pill","sourcePath":"components/core/Pill.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"Field","sourcePath":"components/forms/Field.jsx"},{"name":"SearchInput","sourcePath":"components/forms/SearchInput.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"126d9578449c","components/core/Badge.jsx":"1978de8ae6f4","components/core/Button.jsx":"b1dce3f64802","components/core/Card.jsx":"6e7a6b58d6af","components/core/EmptyState.jsx":"673c98835152","components/core/Pill.jsx":"ea5c91d584e3","components/core/Tag.jsx":"9f64c194d333","components/forms/Field.jsx":"e51113976516","components/forms/SearchInput.jsx":"68b1ff60f247","ui_kits/patient-records/DirectoryScreen.jsx":"1028b851df77","ui_kits/patient-records/HomeShell.jsx":"85e3b7baebad","ui_kits/patient-records/OnboardingScreens.jsx":"06cf5e414101","ui_kits/patient-records/OverviewScreen.jsx":"9e5e9fdb9ad9","ui_kits/patient-records/RecordsScreen.jsx":"fac93f3bffb4","ui_kits/patient-records/SearchScreen.jsx":"8a2d0aa0cdd4","ui_kits/patient-records/SettingsScreen.jsx":"97600783bced","ui_kits/patient-records/WelcomeScreen.jsx":"d55c18965f12","ui_kits/patient-records/data.js":"781cfa29febe"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.DentMemoDesignSystem_43f866 = window.DentMemoDesignSystem_43f866 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
function Avatar({
  name = "",
  gender = "X",
  size = 36
}) {
  const initials = (name || "?").split(" ").map(w => w[0]).join("").slice(0, 2).toUpperCase();
  const map = {
    M: {
      background: "var(--blue-l)",
      color: "var(--blue)"
    },
    F: {
      background: "var(--pink-l)",
      color: "var(--pink)"
    },
    X: {
      background: "var(--border)",
      color: "var(--muted)"
    }
  };
  const s = map[gender] || map.X;
  return React.createElement("div", {
    style: {
      width: size,
      height: size,
      borderRadius: "50%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontWeight: 800,
      flexShrink: 0,
      fontFamily: "var(--font-sans)",
      fontSize: size * 0.38,
      ...s
    }
  }, initials);
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function Badge({
  tone = "neutral",
  children
}) {
  const map = {
    M: {
      background: "var(--blue-l)",
      color: "var(--blue)"
    },
    F: {
      background: "var(--pink-l)",
      color: "var(--pink)"
    },
    teal: {
      background: "var(--teal-m)",
      color: "var(--teal-d)"
    },
    neutral: {
      background: "var(--border)",
      color: "var(--muted)"
    }
  };
  const s = map[tone] || map.neutral;
  return React.createElement("span", {
    style: {
      display: "inline-block",
      padding: "2px 8px",
      borderRadius: "20px",
      fontSize: "10px",
      fontWeight: 700,
      fontFamily: "var(--font-sans)",
      ...s
    }
  }, children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function Button({
  variant = "primary",
  size = "md",
  icon,
  children,
  onClick,
  disabled,
  type = "button"
}) {
  const bg = {
    primary: {
      background: "var(--teal)",
      color: "#fff"
    },
    secondary: {
      background: "var(--bg)",
      color: "var(--ink)",
      border: "1.5px solid var(--border)"
    },
    success: {
      background: "var(--green)",
      color: "#fff"
    },
    danger: {
      background: "#fee2e2",
      color: "var(--red)",
      border: "1.5px solid #fecaca"
    }
  }[variant] || {};
  const sz = size === "sm" ? {
    padding: "5px 10px",
    fontSize: "11px",
    borderRadius: "7px"
  } : {
    padding: "9px 16px",
    fontSize: "13px",
    borderRadius: "10px"
  };
  return React.createElement("button", {
    type,
    onClick,
    disabled,
    style: {
      ...sz,
      ...bg,
      fontWeight: 700,
      cursor: disabled ? "default" : "pointer",
      border: bg.border || "none",
      display: "inline-flex",
      alignItems: "center",
      gap: "6px",
      fontFamily: "var(--font-sans)",
      opacity: disabled ? .6 : 1
    }
  }, icon ? React.createElement("span", null, icon) : null, children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function Card({
  title,
  headerRight,
  children,
  padded = true
}) {
  return React.createElement("div", {
    style: {
      background: "#fff",
      border: "1.5px solid var(--border)",
      borderRadius: "14px",
      boxShadow: "var(--shadow)",
      overflow: "hidden",
      fontFamily: "var(--font-sans)"
    }
  }, title ? React.createElement("div", {
    style: {
      padding: "12px 16px",
      borderBottom: "1px solid var(--border)",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      flexWrap: "wrap",
      gap: "8px"
    }
  }, React.createElement("div", {
    style: {
      fontSize: "14px",
      fontWeight: 700
    }
  }, title), headerRight) : null, React.createElement("div", {
    style: padded ? {
      padding: "14px"
    } : null
  }, children));
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/EmptyState.jsx
try { (() => {
function EmptyState({
  icon = "🔍",
  message
}) {
  return React.createElement("div", {
    style: {
      textAlign: "center",
      padding: "40px 20px",
      color: "var(--muted)",
      fontFamily: "var(--font-sans)"
    }
  }, React.createElement("div", {
    style: {
      fontSize: "40px",
      marginBottom: "10px"
    }
  }, icon), React.createElement("p", null, message));
}
Object.assign(__ds_scope, { EmptyState });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/EmptyState.jsx", error: String((e && e.message) || e) }); }

// components/core/Pill.jsx
try { (() => {
function Pill({
  value,
  label,
  tone = "teal"
}) {
  const color = {
    teal: "var(--teal)",
    green: "var(--green)",
    purple: "var(--purple)"
  }[tone] || "var(--teal)";
  return React.createElement("div", {
    style: {
      background: "var(--bg)",
      border: "1.5px solid var(--border)",
      borderRadius: "10px",
      padding: "8px 12px",
      textAlign: "center",
      minWidth: "80px",
      fontFamily: "var(--font-sans)"
    }
  }, React.createElement("div", {
    style: {
      fontSize: "16px",
      fontWeight: 800,
      color
    }
  }, value), React.createElement("div", {
    style: {
      fontSize: "10px",
      color: "var(--muted)",
      marginTop: "2px"
    }
  }, label));
}
Object.assign(__ds_scope, { Pill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Pill.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function Tag({
  children,
  onRemove
}) {
  return React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "4px",
      background: "var(--teal-l)",
      border: "1px solid var(--teal-m)",
      borderRadius: "20px",
      padding: "3px 9px",
      fontSize: "11px",
      color: "var(--teal-d)",
      fontFamily: "var(--font-sans)"
    }
  }, children, onRemove ? React.createElement("span", {
    onClick: onRemove,
    style: {
      cursor: "pointer",
      color: "var(--red)",
      fontSize: "13px",
      fontWeight: 700,
      lineHeight: 1
    }
  }, "×") : null);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/forms/Field.jsx
try { (() => {
function Field({
  label,
  type = "text",
  value,
  onChange,
  options,
  placeholder,
  required,
  full
}) {
  const base = {
    padding: "9px 11px",
    border: "1.5px solid var(--border)",
    borderRadius: "10px",
    fontSize: "13px",
    color: "var(--ink)",
    background: "#fff",
    outline: "none",
    fontFamily: "var(--font-sans)",
    width: "100%"
  };
  let control;
  if (type === "select") {
    control = React.createElement("select", {
      value,
      onChange,
      style: {
        ...base,
        cursor: "pointer"
      }
    }, (options || []).map(o => React.createElement("option", {
      key: o.value,
      value: o.value
    }, o.label)));
  } else if (type === "textarea") {
    control = React.createElement("textarea", {
      value,
      onChange,
      placeholder,
      style: {
        ...base,
        resize: "vertical",
        minHeight: "60px"
      }
    });
  } else {
    control = React.createElement("input", {
      type,
      value,
      onChange,
      placeholder,
      style: base
    });
  }
  return React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "4px",
      gridColumn: full ? "1/-1" : undefined
    }
  }, label ? React.createElement("label", {
    style: {
      fontSize: "10px",
      fontWeight: 700,
      color: "var(--muted)",
      letterSpacing: ".3px",
      textTransform: "uppercase"
    }
  }, label, required ? " *" : "") : null, control);
}
Object.assign(__ds_scope, { Field });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Field.jsx", error: String((e && e.message) || e) }); }

// components/forms/SearchInput.jsx
try { (() => {
function SearchInput({
  value,
  onChange,
  placeholder = "Search by name, phone, or Patient ID…",
  suggestions,
  onSelect
}) {
  return React.createElement("div", {
    style: {
      position: "relative",
      marginBottom: "12px",
      fontFamily: "var(--font-sans)"
    }
  }, React.createElement("svg", {
    width: 16,
    height: 16,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: 2,
    style: {
      position: "absolute",
      left: 12,
      top: "50%",
      transform: "translateY(-50%)",
      color: "var(--muted)",
      pointerEvents: "none"
    }
  }, React.createElement("circle", {
    cx: 11,
    cy: 11,
    r: 8
  }), React.createElement("path", {
    d: "m21 21-4.35-4.35"
  })), React.createElement("input", {
    value,
    onChange,
    placeholder,
    autoComplete: "off",
    style: {
      width: "100%",
      padding: "12px 12px 12px 40px",
      border: "1.5px solid var(--border)",
      borderRadius: "12px",
      fontSize: "14px",
      background: "#fff",
      outline: "none"
    }
  }), suggestions && suggestions.length > 0 ? React.createElement("div", {
    style: {
      position: "absolute",
      top: "calc(100% + 4px)",
      left: 0,
      right: 0,
      background: "#fff",
      border: "1.5px solid var(--border)",
      borderRadius: "12px",
      boxShadow: "var(--shadow)",
      maxHeight: 260,
      overflowY: "auto",
      zIndex: 100
    }
  }, suggestions.map((s, i) => React.createElement("div", {
    key: i,
    onClick: () => onSelect && onSelect(s),
    style: {
      padding: "10px 14px",
      cursor: "pointer",
      display: "flex",
      flexDirection: "column",
      gap: 2,
      borderBottom: i < suggestions.length - 1 ? "1px solid var(--border)" : "none"
    }
  }, React.createElement("span", {
    style: {
      fontWeight: 600,
      fontSize: 13
    }
  }, s.name), React.createElement("span", {
    style: {
      fontSize: 11,
      color: "var(--muted)"
    }
  }, s.sub)))) : null);
}
Object.assign(__ds_scope, { SearchInput });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/SearchInput.jsx", error: String((e && e.message) || e) }); }

// ui_kits/patient-records/DirectoryScreen.jsx
try { (() => {
function RowMenu({
  onMerge,
  onDelete,
  visitCount
}) {
  const [open, setOpen] = React.useState(false);
  const [confirm, setConfirm] = React.useState(false);
  const label = confirm ? `Confirm delete (+ ${visitCount} visit${visitCount === 1 ? '' : 's'})` : visitCount === 0 ? 'Delete patient' : 'Delete patient…';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setOpen(!open),
    style: {
      padding: '3px 8px',
      fontSize: 13,
      fontWeight: 700,
      background: 'none',
      border: '1.5px solid var(--border)',
      borderRadius: 6,
      cursor: 'pointer',
      color: 'var(--muted)'
    }
  }, "\u22EF"), open ? /*#__PURE__*/React.createElement("div", {
    onMouseLeave: () => {
      setOpen(false);
      setConfirm(false);
    },
    style: {
      position: 'absolute',
      top: '100%',
      right: 0,
      background: '#fff',
      border: '1.5px solid var(--border)',
      borderRadius: 8,
      boxShadow: 'var(--shadow)',
      zIndex: 30,
      minWidth: 170,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: () => {
      onMerge();
      setOpen(false);
    },
    style: {
      padding: '8px 12px',
      fontSize: 12,
      cursor: 'pointer',
      color: 'var(--ink)'
    }
  }, "Select to merge"), /*#__PURE__*/React.createElement("div", {
    onClick: () => {
      if (confirm) {
        onDelete();
        setOpen(false);
        setConfirm(false);
      } else {
        setConfirm(true);
      }
    },
    style: {
      padding: '8px 12px',
      fontSize: 12,
      cursor: 'pointer',
      color: 'var(--red)',
      fontWeight: confirm ? 700 : 400,
      background: confirm ? '#fee2e2' : 'transparent'
    }
  }, label)) : null);
}
function DirectoryScreen({
  patients,
  setPatients,
  visits,
  setVisits,
  treatments,
  doctorMode
}) {
  const {
    inputSm,
    fmtA,
    initials,
    genderColor
  } = window.dmHelpers;
  const [q, setQ] = React.useState('');
  const [editing, setEditing] = React.useState(null);
  const [adding, setAdding] = React.useState(false);
  const [newP, setNewP] = React.useState({
    name: '',
    age: '',
    gender: '',
    phone: ''
  });
  const [merge, setMerge] = React.useState([]);
  const visitCount = pid => visits.filter(v => v.patientId === pid).length;
  const filtered = patients.filter(p => p.name.toLowerCase().includes(q.toLowerCase()) || p.phone.includes(q));
  const saveField = (id, field, val) => setPatients(patients.map(p => p.id === id ? {
    ...p,
    [field]: val
  } : p));
  const toggleMerge = id => setMerge(m => m.includes(id) ? m.filter(x => x !== id) : m.length < 2 ? [...m, id] : m);
  const doMerge = () => {
    if (merge.length !== 2) return;
    const [keepId, dropId] = merge;
    setVisits(visits.map(v => v.patientId === dropId ? {
      ...v,
      patientId: keepId
    } : v));
    setPatients(patients.filter(p => p.id !== dropId));
    setMerge([]);
  };
  const addPatient = () => {
    if (!newP.name) return;
    const nid = Math.max(0, ...patients.map(p => p.id)) + 1;
    setPatients([...patients, {
      id: nid,
      pid: 'PT-' + (10000 + nid),
      name: newP.name,
      age: +newP.age || 0,
      gender: newP.gender,
      phone: newP.phone
    }]);
    setNewP({
      name: '',
      age: '',
      gender: '',
      phone: ''
    });
    setAdding(false);
  };
  const delPatient = id => {
    setVisits(visits.filter(v => v.patientId !== id));
    setPatients(patients.filter(p => p.id !== id));
  };
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap',
      marginBottom: 10,
      alignItems: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 160
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: q,
    onChange: e => setQ(e.target.value),
    placeholder: "Name or phone\u2026",
    style: inputSm
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--muted)',
      paddingBottom: 8
    }
  }, filtered.length, " patients"), /*#__PURE__*/React.createElement("button", {
    onClick: () => setAdding(true),
    style: {
      padding: '5px 10px',
      borderRadius: 7,
      fontSize: 11,
      fontWeight: 700,
      cursor: 'pointer',
      border: 'none',
      background: 'var(--teal)',
      color: '#fff'
    }
  }, "+ Add")), merge.length > 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--teal)',
      color: '#fff',
      padding: '10px 14px',
      borderRadius: 10,
      marginBottom: 10,
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      gap: 10,
      fontSize: 12,
      fontWeight: 600
    }
  }, /*#__PURE__*/React.createElement("span", null, merge.length === 1 ? 'Select one more to merge' : 'Ready to merge — first selected patient is kept'), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setMerge([]),
    style: {
      padding: '5px 10px',
      borderRadius: 7,
      fontSize: 11,
      background: 'rgba(255,255,255,.2)',
      color: '#fff',
      border: 'none',
      cursor: 'pointer'
    }
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    onClick: doMerge,
    disabled: merge.length !== 2,
    style: {
      padding: '5px 10px',
      borderRadius: 7,
      fontSize: 11,
      fontWeight: 700,
      background: '#fff',
      color: 'var(--teal)',
      border: 'none',
      cursor: 'pointer',
      opacity: merge.length !== 2 ? .5 : 1
    }
  }, "Merge"))) : null, adding ? /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--amber-l)',
      border: '1px solid var(--amber)',
      borderRadius: 10,
      padding: 12,
      marginBottom: 10,
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(120px,1fr))',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: newP.name,
    onChange: e => setNewP({
      ...newP,
      name: e.target.value
    }),
    placeholder: "Full name",
    style: inputSm
  }), /*#__PURE__*/React.createElement("select", {
    value: newP.gender,
    onChange: e => setNewP({
      ...newP,
      gender: e.target.value
    }),
    style: inputSm
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "Gender"), /*#__PURE__*/React.createElement("option", {
    value: "M"
  }, "Male"), /*#__PURE__*/React.createElement("option", {
    value: "F"
  }, "Female")), /*#__PURE__*/React.createElement("input", {
    value: newP.age,
    onChange: e => setNewP({
      ...newP,
      age: e.target.value
    }),
    placeholder: "Age",
    style: inputSm
  }), /*#__PURE__*/React.createElement("input", {
    value: newP.phone,
    onChange: e => setNewP({
      ...newP,
      phone: e.target.value
    }),
    placeholder: "Phone",
    style: inputSm
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      gridColumn: '1/-1'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setAdding(false),
    style: {
      padding: '6px 12px',
      borderRadius: 8,
      fontSize: 12,
      border: '1.5px solid var(--border)',
      background: '#fff',
      cursor: 'pointer'
    }
  }, "Cancel"), /*#__PURE__*/React.createElement("button", {
    onClick: addPatient,
    style: {
      padding: '6px 12px',
      borderRadius: 8,
      fontSize: 12,
      fontWeight: 700,
      border: 'none',
      background: 'var(--green)',
      color: '#fff',
      cursor: 'pointer'
    }
  }, "\u2713 Add Patient"))) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      border: '1.5px solid var(--border)',
      borderRadius: 14,
      boxShadow: 'var(--shadow)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      overflowX: 'auto'
    }
  }, /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontSize: 12
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, ['ID', 'Name', 'Age', 'Gender', 'Phone', 'Visits', ''].map(h => /*#__PURE__*/React.createElement("th", {
    key: h,
    style: {
      padding: '8px 10px',
      textAlign: 'left',
      fontSize: 10,
      color: 'var(--muted)',
      textTransform: 'uppercase',
      background: 'var(--bg)'
    }
  }, h)))), /*#__PURE__*/React.createElement("tbody", null, filtered.map(p => /*#__PURE__*/React.createElement("tr", {
    key: p.id,
    style: {
      borderBottom: '1px solid var(--border)',
      background: merge.includes(p.id) ? 'var(--teal-l)' : 'transparent'
    }
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '8px 10px',
      fontFamily: 'var(--font-mono)',
      color: 'var(--teal)',
      fontWeight: 700
    }
  }, p.pid), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '8px 10px'
    }
  }, editing === p.id + '-name' ? /*#__PURE__*/React.createElement("input", {
    autoFocus: true,
    defaultValue: p.name,
    onBlur: e => {
      saveField(p.id, 'name', e.target.value);
      setEditing(null);
    },
    style: {
      ...inputSm,
      padding: '2px 4px'
    }
  }) : /*#__PURE__*/React.createElement("span", {
    onClick: () => setEditing(p.id + '-name'),
    style: {
      cursor: 'pointer'
    }
  }, p.name)), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '8px 10px'
    }
  }, editing === p.id + '-age' ? /*#__PURE__*/React.createElement("input", {
    autoFocus: true,
    defaultValue: p.age,
    onBlur: e => {
      saveField(p.id, 'age', e.target.value);
      setEditing(null);
    },
    style: {
      ...inputSm,
      padding: '2px 4px',
      width: 50
    }
  }) : /*#__PURE__*/React.createElement("span", {
    onClick: () => setEditing(p.id + '-age'),
    style: {
      cursor: 'pointer'
    }
  }, p.age)), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '8px 10px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      padding: '2px 8px',
      borderRadius: 20,
      fontSize: 10,
      fontWeight: 700,
      ...genderColor(p.gender)
    }
  }, p.gender || '—')), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '8px 10px'
    }
  }, editing === p.id + '-phone' ? /*#__PURE__*/React.createElement("input", {
    autoFocus: true,
    defaultValue: p.phone,
    onBlur: e => {
      saveField(p.id, 'phone', e.target.value);
      setEditing(null);
    },
    style: {
      ...inputSm,
      padding: '2px 4px'
    }
  }) : /*#__PURE__*/React.createElement("span", {
    onClick: () => setEditing(p.id + '-phone'),
    style: {
      cursor: 'pointer'
    }
  }, p.phone)), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '8px 10px'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      background: 'var(--teal-m)',
      color: 'var(--teal-d)',
      borderRadius: 20,
      padding: '2px 8px',
      fontSize: 11,
      fontWeight: 700
    }
  }, visitCount(p.id))), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '8px 10px',
      textAlign: 'right'
    }
  }, /*#__PURE__*/React.createElement(RowMenu, {
    onMerge: () => toggleMerge(p.id),
    onDelete: () => delPatient(p.id),
    visitCount: visitCount(p.id)
  })))))))), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 11,
      color: 'var(--muted)',
      marginTop: 8
    }
  }, "Tap Name/Age/Phone to edit. Use \u22EF on a row to select it for merge or delete it."));
}
window.DirectoryScreen = DirectoryScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/patient-records/DirectoryScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/patient-records/HomeShell.jsx
try { (() => {
const inputSm = {
  padding: '9px 11px',
  border: '1.5px solid var(--border)',
  borderRadius: 10,
  fontSize: 13,
  fontFamily: 'inherit',
  outline: 'none',
  width: '100%'
};
const labelSm = {
  fontSize: 10,
  fontWeight: 700,
  color: 'var(--muted)',
  letterSpacing: '.3px',
  textTransform: 'uppercase',
  display: 'block',
  marginBottom: 4
};
function AddVisitScreen({
  patients,
  setPatients,
  treatments,
  consultants,
  setVisits,
  visits,
  prefill,
  onSaved
}) {
  const [f, setF] = React.useState({
    name: prefill ? prefill.name : '',
    date: '',
    diagnosis: '',
    treatment: '',
    consultant: '',
    drFees: '',
    clinicShare: '',
    labCost: '',
    remarks: ''
  });
  const [saved, setSaved] = React.useState(false);
  const set = k => e => setF({
    ...f,
    [k]: e.target.value
  });
  const matches = f.name && !prefill ? patients.filter(p => p.name.toLowerCase().includes(f.name.toLowerCase())) : [];
  const [linked, setLinked] = React.useState(prefill || null);
  const save = () => {
    let patient = linked || patients.find(p => p.name.toLowerCase() === f.name.toLowerCase());
    if (!patient) {
      const nid = Math.max(0, ...patients.map(p => p.id)) + 1;
      patient = {
        id: nid,
        pid: 'PT-' + (10000 + nid),
        name: f.name,
        age: 0,
        gender: '',
        phone: ''
      };
      setPatients([...patients, patient]);
    }
    const nid = Math.max(0, ...visits.map(v => v.id)) + 1;
    setVisits([...visits, {
      id: nid,
      patientId: patient.id,
      date: f.date,
      diagnosis: f.diagnosis,
      treatment: f.treatment,
      consultant: f.consultant,
      drFees: +f.drFees || 0,
      clinicShare: +f.clinicShare || 0,
      labCost: +f.labCost || 0,
      remarks: f.remarks
    }]);
    setSaved(true);
    setTimeout(() => onSaved && onSaved(), 900);
  };
  if (saved) return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '40px 20px',
      color: 'var(--green)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 40,
      marginBottom: 10
    }
  }, "\u2713"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontWeight: 700
    }
  }, "Visit saved"));
  const patientResolved = linked || patients.find(p => p.name.toLowerCase() === f.name.toLowerCase());
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      border: '1.5px solid var(--border)',
      borderRadius: 14,
      boxShadow: 'var(--shadow)',
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(160px,1fr))',
      gap: 10,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("label", {
    style: labelSm
  }, "Patient Name *"), /*#__PURE__*/React.createElement("input", {
    style: inputSm,
    value: f.name,
    onChange: e => {
      setLinked(null);
      setF({
        ...f,
        name: e.target.value
      });
    },
    placeholder: "Type to search\u2026",
    disabled: !!prefill
  }), matches.length > 0 && !linked ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: '100%',
      left: 0,
      right: 0,
      background: '#fff',
      border: '1.5px solid var(--border)',
      borderRadius: 10,
      boxShadow: 'var(--shadow)',
      zIndex: 20
    }
  }, matches.map(p => /*#__PURE__*/React.createElement("div", {
    key: p.id,
    onClick: () => {
      setLinked(p);
      setF({
        ...f,
        name: p.name
      });
    },
    style: {
      padding: '8px 12px',
      cursor: 'pointer',
      fontSize: 12,
      borderBottom: '1px solid var(--border)'
    }
  }, p.name, " ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--muted)'
    }
  }, "\xB7 ", p.pid)))) : null, !patientResolved && f.name ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--amber)',
      marginTop: 4
    }
  }, "New patient \u2014 will be added as \"", f.name, "\" on save") : null), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: labelSm
  }, "Date *"), /*#__PURE__*/React.createElement("input", {
    type: "date",
    style: inputSm,
    value: f.date,
    onChange: set('date')
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: '1/-1'
    }
  }, /*#__PURE__*/React.createElement("label", {
    style: labelSm
  }, "Diagnosis / Tooth"), /*#__PURE__*/React.createElement("input", {
    style: inputSm,
    value: f.diagnosis,
    onChange: set('diagnosis')
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: '1/-1'
    }
  }, /*#__PURE__*/React.createElement("label", {
    style: labelSm
  }, "Treatment"), /*#__PURE__*/React.createElement("select", {
    style: inputSm,
    value: f.treatment,
    onChange: set('treatment')
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "\u2014 Select treatment \u2014"), treatments.map(t => /*#__PURE__*/React.createElement("option", {
    key: t
  }, t)))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: labelSm
  }, "Consultant"), /*#__PURE__*/React.createElement("select", {
    style: inputSm,
    value: f.consultant,
    onChange: set('consultant')
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "\u2014 Select \u2014"), consultants.map(c => /*#__PURE__*/React.createElement("option", {
    key: c
  }, c)))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: labelSm
  }, "Dr Fees (\u20B9)"), /*#__PURE__*/React.createElement("input", {
    type: "number",
    style: inputSm,
    value: f.drFees,
    onChange: set('drFees'),
    placeholder: "0"
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: labelSm
  }, "Clinic Share (\u20B9)"), /*#__PURE__*/React.createElement("input", {
    type: "number",
    style: inputSm,
    value: f.clinicShare,
    onChange: set('clinicShare'),
    placeholder: "0"
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: labelSm
  }, "Lab Cost (\u20B9)"), /*#__PURE__*/React.createElement("input", {
    type: "number",
    style: inputSm,
    value: f.labCost,
    onChange: set('labCost'),
    placeholder: "0"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      gridColumn: '1/-1'
    }
  }, /*#__PURE__*/React.createElement("label", {
    style: labelSm
  }, "Remarks"), /*#__PURE__*/React.createElement("textarea", {
    style: {
      ...inputSm,
      minHeight: 60,
      resize: 'vertical'
    },
    value: f.remarks,
    onChange: set('remarks')
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setF({
      name: prefill ? prefill.name : '',
      date: '',
      diagnosis: '',
      treatment: '',
      consultant: '',
      drFees: '',
      clinicShare: '',
      labCost: '',
      remarks: ''
    }),
    style: {
      padding: '9px 16px',
      borderRadius: 10,
      fontSize: 13,
      fontWeight: 700,
      cursor: 'pointer',
      border: '1.5px solid var(--border)',
      background: 'var(--bg)',
      color: 'var(--ink)'
    }
  }, "Clear"), /*#__PURE__*/React.createElement("button", {
    onClick: save,
    disabled: !f.name || !f.date,
    style: {
      padding: '9px 16px',
      borderRadius: 10,
      fontSize: 13,
      fontWeight: 700,
      cursor: 'pointer',
      border: 'none',
      background: 'var(--green)',
      color: '#fff',
      opacity: !f.name || !f.date ? .5 : 1
    }
  }, "\u2713 Save Visit")));
}
function HomeShell(props) {
  const {
    clinicName,
    setClinicName,
    logo,
    setLogo,
    patients,
    setPatients,
    visits,
    setVisits,
    treatments,
    setTreatments,
    consultants,
    setConsultants,
    doctorMode,
    onRequestDoctorMode,
    onLockAssistant,
    onLogout
  } = props;
  const tabs = ['Search', '+ Visit', 'Directory', 'Records'];
  const doctorTabs = ['Overview', '⚙ Settings'];
  const [active, setActive] = React.useState('Search');
  const [prefill, setPrefill] = React.useState(null);
  const goAddVisit = p => {
    setPrefill(p);
    setActive('+ Visit');
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100vh',
      background: 'var(--bg)',
      fontFamily: 'var(--font-sans)'
    }
  }, /*#__PURE__*/React.createElement("nav", {
    style: {
      background: 'linear-gradient(135deg,var(--teal),var(--teal-d))',
      color: '#fff',
      padding: '0 14px',
      display: 'flex',
      alignItems: 'center',
      gap: 6,
      height: 56,
      boxShadow: '0 2px 12px rgba(13,148,136,.3)',
      overflowX: 'auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      marginRight: 'auto'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: logo || '../../assets/logo-mark.png',
    style: {
      height: 32,
      width: 32,
      objectFit: 'contain',
      background: '#fff',
      borderRadius: 6,
      padding: 2
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 800,
      display: 'block'
    }
  }, clinicName || "Dr. Blessin's"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 2
    }
  }, tabs.map(t => /*#__PURE__*/React.createElement("button", {
    key: t,
    onClick: () => {
      setActive(t);
      if (t !== '+ Visit') setPrefill(null);
    },
    style: {
      padding: '7px 10px',
      borderRadius: 8,
      fontSize: 11,
      fontWeight: 600,
      border: 'none',
      background: active === t ? 'rgba(255,255,255,.22)' : 'none',
      color: '#fff',
      cursor: 'pointer'
    }
  }, t)), doctorMode ? doctorTabs.map(t => /*#__PURE__*/React.createElement("button", {
    key: t,
    onClick: () => setActive(t),
    style: {
      padding: '7px 10px',
      borderRadius: 8,
      fontSize: 11,
      fontWeight: 600,
      border: 'none',
      background: active === t ? 'rgba(255,255,255,.22)' : 'none',
      color: '#fff',
      cursor: 'pointer'
    }
  }, t)) : null, /*#__PURE__*/React.createElement("button", {
    onClick: doctorMode ? onLockAssistant : onRequestDoctorMode,
    style: {
      padding: '7px 10px',
      borderRadius: 8,
      fontSize: 11,
      fontWeight: 600,
      border: 'none',
      background: 'none',
      color: 'rgba(255,255,255,.85)',
      cursor: 'pointer'
    }
  }, doctorMode ? '🔓 Doctor' : '🔒 Unlock Doctor'), /*#__PURE__*/React.createElement("button", {
    onClick: onLogout,
    style: {
      padding: '7px 10px',
      borderRadius: 8,
      fontSize: 11,
      fontWeight: 600,
      border: 'none',
      background: 'none',
      color: 'rgba(255,255,255,.7)',
      cursor: 'pointer'
    }
  }, "Logout"))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 14,
      maxWidth: 1200,
      margin: '0 auto'
    }
  }, active === 'Search' ? /*#__PURE__*/React.createElement(SearchScreen, {
    patients: patients,
    visits: visits,
    doctorMode: doctorMode,
    onGoAddVisit: goAddVisit
  }) : null, active === '+ Visit' ? /*#__PURE__*/React.createElement(AddVisitScreen, {
    patients: patients,
    setPatients: setPatients,
    treatments: treatments,
    consultants: consultants,
    visits: visits,
    setVisits: setVisits,
    prefill: prefill,
    onSaved: () => {
      setActive('Search');
      setPrefill(null);
    }
  }) : null, active === 'Directory' ? /*#__PURE__*/React.createElement(DirectoryScreen, {
    patients: patients,
    setPatients: setPatients,
    visits: visits,
    setVisits: setVisits,
    treatments: treatments,
    doctorMode: doctorMode
  }) : null, active === 'Records' ? /*#__PURE__*/React.createElement(RecordsScreen, {
    patients: patients,
    visits: visits,
    treatments: treatments,
    consultants: consultants,
    doctorMode: doctorMode
  }) : null, active === 'Overview' ? /*#__PURE__*/React.createElement(OverviewScreen, {
    patients: patients,
    visits: visits,
    doctorMode: doctorMode
  }) : null, active === '⚙ Settings' ? /*#__PURE__*/React.createElement(SettingsScreen, {
    clinicName: clinicName,
    setClinicName: setClinicName,
    logo: logo,
    setLogo: setLogo,
    treatments: treatments,
    setTreatments: setTreatments,
    consultants: consultants,
    setConsultants: setConsultants,
    onLockAssistant: () => {
      onLockAssistant();
      setActive('Search');
    }
  }) : null));
}
window.HomeShell = HomeShell;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/patient-records/HomeShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/patient-records/OnboardingScreens.jsx
try { (() => {
function OnboardingShell({
  step,
  total,
  title,
  subtitle,
  children,
  onBack,
  onNext,
  nextLabel = "Continue",
  nextDisabled
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100vh',
      background: 'var(--bg)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      borderRadius: 20,
      padding: '28px',
      width: 380,
      boxShadow: 'var(--shadow-lg)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 4,
      marginBottom: 18
    }
  }, Array.from({
    length: total
  }).map((_, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      height: 3,
      borderRadius: 2,
      background: i < step ? 'var(--teal)' : 'var(--border)'
    }
  }))), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 16,
      fontWeight: 800,
      marginBottom: 4
    }
  }, title), subtitle ? /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: 'var(--muted)',
      marginBottom: 16
    }
  }, subtitle) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 20
    }
  }, children), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      justifyContent: 'space-between'
    }
  }, onBack ? /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      padding: '9px 14px',
      borderRadius: 10,
      border: '1.5px solid var(--border)',
      background: '#fff',
      color: 'var(--muted)',
      fontWeight: 700,
      fontSize: 13,
      cursor: 'pointer'
    }
  }, "Back") : /*#__PURE__*/React.createElement("span", null), /*#__PURE__*/React.createElement("button", {
    onClick: onNext,
    disabled: nextDisabled,
    style: {
      padding: '9px 18px',
      borderRadius: 10,
      border: 'none',
      background: 'var(--teal)',
      color: '#fff',
      fontWeight: 700,
      fontSize: 13,
      cursor: nextDisabled ? 'default' : 'pointer',
      opacity: nextDisabled ? .5 : 1
    }
  }, nextLabel))));
}
const inputStyle = {
  width: '100%',
  padding: '9px 11px',
  border: '1.5px solid var(--border)',
  borderRadius: 10,
  fontSize: 13,
  fontFamily: 'inherit',
  outline: 'none'
};
const labelStyle = {
  fontSize: 10,
  fontWeight: 700,
  color: 'var(--muted)',
  letterSpacing: '.3px',
  textTransform: 'uppercase',
  display: 'block',
  marginBottom: 4
};
function ClinicSetupScreen({
  data,
  setData,
  onBack,
  onNext
}) {
  return /*#__PURE__*/React.createElement(OnboardingShell, {
    step: 1,
    total: 4,
    title: "Create your clinic",
    subtitle: "This becomes your clinic's private workspace.",
    onBack: onBack,
    onNext: onNext,
    nextDisabled: !data.doctorName || !data.clinicName
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: labelStyle
  }, "Doctor Name *"), /*#__PURE__*/React.createElement("input", {
    style: inputStyle,
    value: data.doctorName,
    onChange: e => setData({
      ...data,
      doctorName: e.target.value
    }),
    placeholder: "Dr. Jane Doe"
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: labelStyle
  }, "Clinic Name *"), /*#__PURE__*/React.createElement("input", {
    style: inputStyle,
    value: data.clinicName,
    onChange: e => setData({
      ...data,
      clinicName: e.target.value
    }),
    placeholder: "Sunrise Dental Studio"
  }))));
}
function LogoSetupScreen({
  data,
  setData,
  onBack,
  onNext
}) {
  return /*#__PURE__*/React.createElement(OnboardingShell, {
    step: 2,
    total: 4,
    title: "Add your logo",
    subtitle: "Optional \u2014 shown in your nav bar and login screen. You can add this later in Settings.",
    onBack: onBack,
    onNext: onNext,
    nextLabel: data.logo ? "Continue" : "Skip for now"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 10,
      padding: '12px 0'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 64,
      height: 64,
      borderRadius: 12,
      background: 'var(--bg)',
      border: '1.5px dashed var(--border)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 22,
      color: 'var(--muted)'
    }
  }, data.logo ? '✓' : '+'), /*#__PURE__*/React.createElement("button", {
    onClick: () => setData({
      ...data,
      logo: !data.logo
    }),
    style: {
      fontSize: 12,
      color: 'var(--teal)',
      fontWeight: 700,
      background: 'none',
      border: 'none',
      cursor: 'pointer'
    }
  }, data.logo ? 'Logo added (demo)' : 'Upload image')));
}
function PinSetupScreen({
  data,
  setData,
  onBack,
  onNext
}) {
  const digits = data.pin || '';
  const press = k => {
    if (k === 'del') {
      setData(prev => ({
        ...prev,
        pin: (prev.pin || '').slice(0, -1)
      }));
      return;
    }
    setData(prev => {
      const cur = prev.pin || '';
      return cur.length < 4 ? {
        ...prev,
        pin: cur + k
      } : prev;
    });
  };
  return /*#__PURE__*/React.createElement(OnboardingShell, {
    step: 3,
    total: 4,
    title: "Create a Doctor PIN",
    subtitle: "Protects financials, exports and settings when a device is used in Assistant Mode.",
    onBack: onBack,
    onNext: onNext,
    nextDisabled: digits.length !== 4
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'center',
      gap: 10,
      marginBottom: 16
    }
  }, [0, 1, 2, 3].map(i => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      width: 12,
      height: 12,
      borderRadius: '50%',
      background: i < digits.length ? 'var(--teal)' : 'var(--border)'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3,1fr)',
      gap: 8
    }
  }, ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', 'del'].map((k, i) => k === '' ? /*#__PURE__*/React.createElement("span", {
    key: i
  }) : /*#__PURE__*/React.createElement("button", {
    key: i,
    onClick: () => press(k),
    style: {
      padding: 14,
      borderRadius: 10,
      border: '1.5px solid var(--border)',
      background: '#fff',
      fontSize: 16,
      fontWeight: 700,
      cursor: 'pointer',
      color: 'var(--ink)'
    }
  }, k === 'del' ? '⌫' : k))));
}
function TreatmentsSetupScreen({
  data,
  setData,
  onBack,
  onNext
}) {
  const defaults = ["Consult", "Cleaning", "Extraction", "RCT", "Composite Filling", "Crown Cementation"];
  const picked = data.treatments || defaults;
  const toggle = t => setData({
    ...data,
    treatments: picked.includes(t) ? picked.filter(x => x !== t) : [...picked, t]
  });
  return /*#__PURE__*/React.createElement(OnboardingShell, {
    step: 4,
    total: 4,
    title: "Starter treatments",
    subtitle: "Pre-selected \u2014 add or remove any time in Settings.",
    onBack: onBack,
    onNext: onNext,
    nextLabel: "Open DentMemo"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 6
    }
  }, defaults.map(t => /*#__PURE__*/React.createElement("button", {
    key: t,
    onClick: () => toggle(t),
    style: {
      padding: '6px 12px',
      borderRadius: 20,
      fontSize: 12,
      fontWeight: 600,
      cursor: 'pointer',
      border: picked.includes(t) ? '1px solid var(--teal-m)' : '1.5px solid var(--border)',
      background: picked.includes(t) ? 'var(--teal-l)' : '#fff',
      color: picked.includes(t) ? 'var(--teal-d)' : 'var(--muted)'
    }
  }, picked.includes(t) ? '✓ ' : '', t))));
}
Object.assign(window, {
  ClinicSetupScreen,
  LogoSetupScreen,
  PinSetupScreen,
  TreatmentsSetupScreen
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/patient-records/OnboardingScreens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/patient-records/OverviewScreen.jsx
try { (() => {
function OverviewScreen({
  patients,
  visits,
  doctorMode
}) {
  const {
    fmtA
  } = window.dmHelpers;
  const [period, setPeriod] = React.useState('all');
  const [selMonth, setSelMonth] = React.useState(null);
  const [tab, setTab] = React.useState('treatments');
  if (!doctorMode) return /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '40px 20px',
      color: 'var(--muted)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 40,
      marginBottom: 10
    }
  }, "\uD83D\uDD12"), /*#__PURE__*/React.createElement("p", null, "Overview is doctor-only. Unlock Doctor Mode to view clinic stats."));
  const now = new Date('2026-07-31');
  const cutoff = {
    today: 1,
    week: 7,
    month: 31,
    all: 99999
  }[period];
  const inRange = v => {
    const d = new Date(v.date);
    return (now - d) / 86400000 <= cutoff;
  };
  const rangeVisits = visits.filter(inRange);
  const totalRevenue = rangeVisits.reduce((s, v) => s + (+v.drFees || 0) + (+v.clinicShare || 0), 0);
  const prevRangeVisits = visits.filter(v => {
    const d = new Date(v.date);
    const diff = (now - d) / 86400000;
    return diff > cutoff && diff <= cutoff * 2;
  });
  const trend = prevRangeVisits.length ? Math.round((rangeVisits.length - prevRangeVisits.length) / prevRangeVisits.length * 100) : null;
  const byMonth = {};
  visits.forEach(v => {
    const m = v.date.slice(0, 7);
    byMonth[m] = (byMonth[m] || 0) + 1;
  });
  const months = Object.keys(byMonth).sort();
  const max = Math.max(1, ...months.map(m => byMonth[m]));
  const byTreatment = {};
  rangeVisits.forEach(v => {
    byTreatment[v.treatment] = (byTreatment[v.treatment] || 0) + 1;
  });
  const topTreatments = Object.entries(byTreatment).sort((a, b) => b[1] - a[1]).slice(0, 6);
  const maxT = Math.max(1, ...topTreatments.map(t => t[1]));
  const byCons = {};
  rangeVisits.forEach(v => {
    byCons[v.consultant] = (byCons[v.consultant] || 0) + 1;
  });
  const topCons = Object.entries(byCons).sort((a, b) => b[1] - a[1]);
  const maxC = Math.max(1, ...topCons.map(c => c[1]));
  const palette = ['var(--teal)', 'var(--purple)', 'var(--sky)', 'var(--green)', 'var(--amber)', '#94a3b8'];
  const Stat = ({
    icon,
    val,
    label,
    color,
    sub
  }) => /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      border: '1.5px solid var(--border)',
      borderRadius: 14,
      padding: '14px',
      boxShadow: 'var(--shadow)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 18
    }
  }, icon), sub != null ? /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      fontWeight: 700,
      color: sub >= 0 ? 'var(--green)' : 'var(--red)'
    }
  }, sub >= 0 ? '▲' : '▼', " ", Math.abs(sub), "%") : null), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 22,
      fontWeight: 800,
      color
    }
  }, val), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--muted)',
      marginTop: 2
    }
  }, label));
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      marginBottom: 14,
      padding: 5,
      borderRadius: 20,
      display: 'inline-flex',
      gap: 2,
      overflowX: 'auto',
      maxWidth: '100%',
      background: 'linear-gradient(135deg,rgba(219,232,255,.55),rgba(255,255,255,.35))',
      backdropFilter: 'blur(16px) saturate(180%)',
      WebkitBackdropFilter: 'blur(16px) saturate(180%)',
      border: '1px solid rgba(255,255,255,.6)',
      boxShadow: '0 4px 20px rgba(13,27,61,.10), inset 0 1px 0 rgba(255,255,255,.9)'
    }
  }, [['today', 'Today'], ['week', 'This Week'], ['month', 'This Month'], ['all', 'All Time']].map(([k, l]) => /*#__PURE__*/React.createElement("button", {
    key: k,
    onClick: () => setPeriod(k),
    style: {
      whiteSpace: 'nowrap',
      padding: '7px 16px',
      borderRadius: 16,
      fontSize: 12,
      fontWeight: 600,
      cursor: 'pointer',
      border: period === k ? '1px solid rgba(255,255,255,.7)' : 'none',
      background: period === k ? 'rgba(255,255,255,.75)' : 'transparent',
      backdropFilter: period === k ? 'blur(6px)' : 'none',
      color: period === k ? 'var(--teal-d)' : 'var(--muted)',
      boxShadow: period === k ? '0 2px 8px rgba(13,27,61,.12), inset 0 1px 0 rgba(255,255,255,.9)' : 'none',
      transition: 'all .2s ease'
    }
  }, l))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(130px,1fr))',
      gap: 10,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement(Stat, {
    icon: "\uD83E\uDDD1\u200D\uD83E\uDD1D\u200D\uD83E\uDDD1",
    val: patients.length,
    label: "Patients",
    color: "var(--teal)"
  }), /*#__PURE__*/React.createElement(Stat, {
    icon: "\uD83D\uDDD3\uFE0F",
    val: rangeVisits.length,
    label: "Visits",
    color: "var(--teal)",
    sub: trend
  }), /*#__PURE__*/React.createElement(Stat, {
    icon: "\uD83D\uDCB0",
    val: fmtA(totalRevenue),
    label: "Collected",
    color: "var(--green)"
  }), /*#__PURE__*/React.createElement(Stat, {
    icon: "\uD83E\uDDB7",
    val: Object.keys(byCons).length,
    label: "Consultants",
    color: "var(--purple)"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      border: '1.5px solid var(--border)',
      borderRadius: 14,
      boxShadow: 'var(--shadow)',
      padding: 14,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'baseline',
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 700,
      fontSize: 14
    }
  }, "Monthly Visits"), selMonth ? /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--teal)',
      fontWeight: 700
    }
  }, selMonth, ": ", byMonth[selMonth], " visits") : /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--muted)'
    }
  }, "Tap a bar for detail")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      gap: 6,
      height: 120
    }
  }, months.map(m => /*#__PURE__*/React.createElement("div", {
    key: m,
    onClick: () => setSelMonth(m === selMonth ? null : m),
    style: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 4,
      cursor: 'pointer',
      minWidth: 22
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      background: m === selMonth ? 'var(--teal-d)' : 'var(--teal)',
      borderRadius: '6px 6px 2px 2px',
      height: byMonth[m] / max * 94 + 'px',
      minHeight: 4,
      transition: 'background .15s'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      color: m === selMonth ? 'var(--teal-d)' : 'var(--muted)',
      fontWeight: m === selMonth ? 700 : 400
    }
  }, m.slice(5)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      border: '1.5px solid var(--border)',
      borderRadius: 14,
      boxShadow: 'var(--shadow)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      borderBottom: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setTab('treatments'),
    style: {
      flex: 1,
      padding: '12px',
      fontSize: 13,
      fontWeight: 700,
      border: 'none',
      background: tab === 'treatments' ? 'var(--teal-l)' : '#fff',
      color: tab === 'treatments' ? 'var(--teal-d)' : 'var(--muted)',
      cursor: 'pointer',
      borderBottom: tab === 'treatments' ? '2px solid var(--teal)' : 'none'
    }
  }, "Top Treatments"), /*#__PURE__*/React.createElement("button", {
    onClick: () => setTab('consultants'),
    style: {
      flex: 1,
      padding: '12px',
      fontSize: 13,
      fontWeight: 700,
      border: 'none',
      background: tab === 'consultants' ? 'var(--teal-l)' : '#fff',
      color: tab === 'consultants' ? 'var(--teal-d)' : 'var(--muted)',
      cursor: 'pointer',
      borderBottom: tab === 'consultants' ? '2px solid var(--teal)' : 'none'
    }
  }, "Consultants")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 14
    }
  }, tab === 'treatments' ? topTreatments.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--muted)',
      fontSize: 12,
      textAlign: 'center',
      padding: 10
    }
  }, "No visits in this period") : topTreatments.map(([t, n], i) => /*#__PURE__*/React.createElement("div", {
    key: t,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: palette[i % palette.length],
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      fontSize: 12,
      marginBottom: 3
    }
  }, /*#__PURE__*/React.createElement("span", null, t), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--muted)',
      fontWeight: 700
    }
  }, n)), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--border)',
      borderRadius: 3,
      height: 5
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: palette[i % palette.length],
      borderRadius: 3,
      height: 5,
      width: n / maxT * 100 + '%',
      transition: 'width .3s'
    }
  }))))) : topCons.length === 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--muted)',
      fontSize: 12,
      textAlign: 'center',
      padding: 10
    }
  }, "No visits in this period") : topCons.map(([c, n], i) => /*#__PURE__*/React.createElement("div", {
    key: c,
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 8,
      height: 8,
      borderRadius: '50%',
      background: palette[i % palette.length],
      flexShrink: 0
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      fontSize: 12,
      marginBottom: 3
    }
  }, /*#__PURE__*/React.createElement("span", null, c), /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--muted)',
      fontWeight: 700
    }
  }, n)), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--border)',
      borderRadius: 3,
      height: 5
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: palette[i % palette.length],
      borderRadius: 3,
      height: 5,
      width: n / maxC * 100 + '%',
      transition: 'width .3s'
    }
  }))))))));
}
window.OverviewScreen = OverviewScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/patient-records/OverviewScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/patient-records/RecordsScreen.jsx
try { (() => {
function RecordsScreen({
  patients,
  visits,
  treatments,
  consultants,
  doctorMode
}) {
  const {
    inputSm,
    fmtA,
    fmtD
  } = window.dmHelpers;
  const [name, setName] = React.useState('');
  const [treat, setTreat] = React.useState('');
  const [cons, setCons] = React.useState('');
  const pName = id => {
    const p = patients.find(x => x.id === id);
    return p ? p.name : '—';
  };
  let rows = visits.map(v => ({
    ...v,
    patientName: pName(v.patientId)
  }));
  if (name) rows = rows.filter(r => r.patientName.toLowerCase().includes(name.toLowerCase()));
  if (treat) rows = rows.filter(r => r.treatment === treat);
  if (cons) rows = rows.filter(r => r.consultant === cons);
  rows = rows.sort((a, b) => b.date.localeCompare(a.date));
  const download = (data, scope) => {
    const header = ['Date', 'Patient', 'Diagnosis', 'Treatment', 'Consultant', 'Dr Fees', 'Clinic Share', 'Lab Cost', 'Remarks'];
    const csv = [header.join(',')].concat(data.map(r => [r.date, r.patientName, r.diagnosis, r.treatment, r.consultant, r.drFees, r.clinicShare, r.labCost, '"' + (r.remarks || '').replace(/"/g, '""') + '"'].join(','))).join('\n');
    const blob = new Blob([csv], {
      type: 'text/csv'
    });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'dentmemo-records-' + scope + '.csv';
    document.body.appendChild(a);
    a.click();
    a.remove();
  };
  const total = rows.reduce((s, r) => s + (+r.drFees || 0) + (+r.clinicShare || 0), 0);
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      border: '1.5px solid var(--border)',
      borderRadius: 14,
      boxShadow: 'var(--shadow)',
      padding: '10px 12px',
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap',
      alignItems: 'flex-end'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 140
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: name,
    onChange: e => setName(e.target.value),
    placeholder: "Patient name\u2026",
    style: inputSm
  })), /*#__PURE__*/React.createElement("select", {
    value: treat,
    onChange: e => setTreat(e.target.value),
    style: {
      ...inputSm,
      width: 160
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "All treatments"), treatments.map(t => /*#__PURE__*/React.createElement("option", {
    key: t
  }, t))), /*#__PURE__*/React.createElement("select", {
    value: cons,
    onChange: e => setCons(e.target.value),
    style: {
      ...inputSm,
      width: 140
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: ""
  }, "All consultants"), consultants.map(c => /*#__PURE__*/React.createElement("option", {
    key: c
  }, c))), /*#__PURE__*/React.createElement("button", {
    onClick: () => {
      setName('');
      setTreat('');
      setCons('');
    },
    style: {
      padding: '8px 10px',
      borderRadius: 8,
      border: '1.5px solid var(--border)',
      background: '#fff',
      fontSize: 12,
      cursor: 'pointer'
    }
  }, "\u2715")), doctorMode ? /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8,
      paddingTop: 8,
      borderTop: '1px solid var(--border)',
      fontSize: 12,
      color: 'var(--muted)'
    }
  }, rows.length, " visits \xB7 Total ", fmtA(total)) : null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      marginTop: 8,
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => download(rows, 'filtered'),
    style: {
      padding: '6px 10px',
      borderRadius: 8,
      fontSize: 11,
      border: '1.5px solid var(--border)',
      background: '#fff',
      cursor: 'pointer'
    }
  }, "\u2B07 CSV (Filtered)"), /*#__PURE__*/React.createElement("button", {
    onClick: () => download(visits.map(v => ({
      ...v,
      patientName: pName(v.patientId)
    })), 'all'),
    style: {
      padding: '6px 10px',
      borderRadius: 8,
      fontSize: 11,
      border: '1.5px solid var(--border)',
      background: '#fff',
      cursor: 'pointer'
    }
  }, "\u2B07 CSV (All)"))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      border: '1.5px solid var(--border)',
      borderRadius: 14,
      boxShadow: 'var(--shadow)',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      overflowX: 'auto'
    }
  }, /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse',
      fontSize: 12
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, ['Date', 'Patient', 'Diagnosis', 'Treatment', 'Consultant'].concat(doctorMode ? ['Dr Fees', 'Clinic ₹'] : []).map(h => /*#__PURE__*/React.createElement("th", {
    key: h,
    style: {
      padding: '8px 10px',
      textAlign: h.includes('₹') || h.includes('Fees') ? 'right' : 'left',
      fontSize: 10,
      color: 'var(--muted)',
      textTransform: 'uppercase',
      background: 'var(--bg)'
    }
  }, h)))), /*#__PURE__*/React.createElement("tbody", null, rows.length === 0 ? /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
    colSpan: 7,
    style: {
      padding: 20,
      textAlign: 'center',
      color: 'var(--muted)'
    }
  }, "No visits match these filters")) : rows.map(r => /*#__PURE__*/React.createElement("tr", {
    key: r.id,
    style: {
      borderBottom: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '8px 10px',
      color: 'var(--muted)',
      whiteSpace: 'nowrap'
    }
  }, fmtD(r.date)), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '8px 10px'
    }
  }, r.patientName), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '8px 10px'
    }
  }, r.diagnosis), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '8px 10px'
    }
  }, r.treatment), /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '8px 10px'
    }
  }, r.consultant), doctorMode ? /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '8px 10px',
      textAlign: 'right',
      fontWeight: 700,
      color: 'var(--green)'
    }
  }, fmtA(r.drFees)) : null, doctorMode ? /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '8px 10px',
      textAlign: 'right',
      fontWeight: 700
    }
  }, fmtA(r.clinicShare)) : null)))))));
}
window.RecordsScreen = RecordsScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/patient-records/RecordsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/patient-records/SearchScreen.jsx
try { (() => {
const inputSm = {
  padding: '9px 11px',
  border: '1.5px solid var(--border)',
  borderRadius: 10,
  fontSize: 13,
  fontFamily: 'inherit',
  outline: 'none',
  width: '100%'
};
const labelSm = {
  fontSize: 10,
  fontWeight: 700,
  color: 'var(--muted)',
  letterSpacing: '.3px',
  textTransform: 'uppercase',
  display: 'block',
  marginBottom: 4
};
function fmtA(n) {
  return n && +n > 0 ? '₹' + (+n).toLocaleString('en-IN') : '—';
}
function fmtD(d) {
  if (!d) return '—';
  const p = d.split('-');
  return p[2] + '/' + p[1] + '/' + p[0];
}
function initials(n) {
  return (n || '?').split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
}
function genderColor(g) {
  return g === 'M' ? {
    background: '#dbeafe',
    color: '#1d4ed8'
  } : g === 'F' ? {
    background: '#fce7f3',
    color: '#be185d'
  } : {
    background: 'var(--border)',
    color: 'var(--muted)'
  };
}
function SearchScreen({
  patients,
  visits,
  doctorMode,
  onGoAddVisit
}) {
  const [q, setQ] = React.useState('');
  const [selected, setSelected] = React.useState(null);
  const matches = q.trim() ? patients.filter(p => p.name.toLowerCase().includes(q.toLowerCase()) || p.phone.includes(q) || p.pid.toLowerCase().includes(q.toLowerCase())) : [];
  const patientVisits = selected ? visits.filter(v => v.patientId === selected.id).sort((a, b) => b.date.localeCompare(a.date)) : [];
  const total = patientVisits.reduce((s, v) => s + (+v.drFees || 0) + (+v.clinicShare || 0), 0);
  if (selected) {
    return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("button", {
      onClick: () => setSelected(null),
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 5,
        color: 'var(--muted)',
        fontSize: 12,
        cursor: 'pointer',
        border: '1.5px solid var(--border)',
        borderRadius: 8,
        padding: '5px 10px',
        background: 'none',
        marginBottom: 10
      }
    }, "\u2190 Back"), /*#__PURE__*/React.createElement("div", {
      style: {
        background: '#fff',
        border: '1.5px solid var(--border)',
        borderRadius: 14,
        boxShadow: 'var(--shadow)',
        padding: 16,
        marginBottom: 12,
        display: 'flex',
        gap: 14,
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 52,
        height: 52,
        borderRadius: '50%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontWeight: 800,
        ...genderColor(selected.gender)
      }
    }, initials(selected.name)), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontWeight: 700,
        fontSize: 15
      }
    }, selected.name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: 'var(--muted)'
      }
    }, selected.pid, " \xB7 ", selected.gender === 'M' ? 'Male' : selected.gender === 'F' ? 'Female' : '—', " \xB7 ", selected.age, " yrs \xB7 ", selected.phone)), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        background: 'var(--bg)',
        border: '1.5px solid var(--border)',
        borderRadius: 10,
        padding: '8px 12px',
        textAlign: 'center',
        minWidth: 70
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 16,
        fontWeight: 800,
        color: 'var(--teal)'
      }
    }, patientVisits.length), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 10,
        color: 'var(--muted)'
      }
    }, "Visits")), doctorMode ? /*#__PURE__*/React.createElement("div", {
      style: {
        background: 'var(--bg)',
        border: '1.5px solid var(--border)',
        borderRadius: 10,
        padding: '8px 12px',
        textAlign: 'center',
        minWidth: 70
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 16,
        fontWeight: 800,
        color: 'var(--green)'
      }
    }, fmtA(total)), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 10,
        color: 'var(--muted)'
      }
    }, "Total")) : null)), /*#__PURE__*/React.createElement("div", {
      style: {
        background: '#fff',
        border: '1.5px solid var(--border)',
        borderRadius: 14,
        boxShadow: 'var(--shadow)',
        overflow: 'hidden'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        padding: '12px 16px',
        borderBottom: '1px solid var(--border)',
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontWeight: 700,
        fontSize: 14
      }
    }, "Visit History"), /*#__PURE__*/React.createElement("button", {
      onClick: () => onGoAddVisit(selected),
      style: {
        padding: '5px 10px',
        borderRadius: 7,
        fontSize: 11,
        fontWeight: 700,
        cursor: 'pointer',
        border: 'none',
        background: 'var(--teal)',
        color: '#fff'
      }
    }, "+ Add Visit")), /*#__PURE__*/React.createElement("div", {
      style: {
        overflowX: 'auto'
      }
    }, /*#__PURE__*/React.createElement("table", {
      style: {
        width: '100%',
        borderCollapse: 'collapse',
        fontSize: 12
      }
    }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
      style: {
        padding: '8px 10px',
        textAlign: 'left',
        fontSize: 10,
        color: 'var(--muted)',
        textTransform: 'uppercase',
        background: 'var(--bg)'
      }
    }, "Date"), /*#__PURE__*/React.createElement("th", {
      style: {
        padding: '8px 10px',
        textAlign: 'left',
        fontSize: 10,
        color: 'var(--muted)',
        textTransform: 'uppercase',
        background: 'var(--bg)'
      }
    }, "Treatment"), /*#__PURE__*/React.createElement("th", {
      style: {
        padding: '8px 10px',
        textAlign: 'left',
        fontSize: 10,
        color: 'var(--muted)',
        textTransform: 'uppercase',
        background: 'var(--bg)'
      }
    }, "Diagnosis"), /*#__PURE__*/React.createElement("th", {
      style: {
        padding: '8px 10px',
        textAlign: 'left',
        fontSize: 10,
        color: 'var(--muted)',
        textTransform: 'uppercase',
        background: 'var(--bg)'
      }
    }, "Consultant"), doctorMode ? /*#__PURE__*/React.createElement("th", {
      style: {
        padding: '8px 10px',
        textAlign: 'right',
        fontSize: 10,
        color: 'var(--muted)',
        textTransform: 'uppercase',
        background: 'var(--bg)'
      }
    }, "Fees") : null)), /*#__PURE__*/React.createElement("tbody", null, patientVisits.length === 0 ? /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
      colSpan: 5,
      style: {
        padding: 20,
        textAlign: 'center',
        color: 'var(--muted)'
      }
    }, "No visits yet")) : patientVisits.map(v => /*#__PURE__*/React.createElement("tr", {
      key: v.id,
      style: {
        borderBottom: '1px solid var(--border)'
      }
    }, /*#__PURE__*/React.createElement("td", {
      style: {
        padding: '8px 10px',
        color: 'var(--muted)',
        whiteSpace: 'nowrap'
      }
    }, fmtD(v.date)), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: '8px 10px'
      }
    }, v.treatment || '—'), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: '8px 10px'
      }
    }, v.diagnosis || '—'), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: '8px 10px'
      }
    }, v.consultant || '—'), doctorMode ? /*#__PURE__*/React.createElement("td", {
      style: {
        padding: '8px 10px',
        textAlign: 'right',
        fontWeight: 700,
        color: 'var(--green)'
      }
    }, fmtA((+v.drFees || 0) + (+v.clinicShare || 0))) : null)))))));
  }
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    style: {
      position: 'absolute',
      left: 12,
      top: '50%',
      transform: 'translateY(-50%)',
      color: 'var(--muted)'
    }
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "11",
    cy: "11",
    r: "8"
  }), /*#__PURE__*/React.createElement("path", {
    d: "m21 21-4.35-4.35"
  })), /*#__PURE__*/React.createElement("input", {
    value: q,
    onChange: e => setQ(e.target.value),
    placeholder: "Search by name, phone, or Patient ID\u2026",
    style: {
      width: '100%',
      padding: '12px 12px 12px 40px',
      border: '1.5px solid var(--border)',
      borderRadius: 12,
      fontSize: 14,
      background: '#fff',
      outline: 'none'
    }
  }), matches.length > 0 ? /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 'calc(100% + 4px)',
      left: 0,
      right: 0,
      background: '#fff',
      border: '1.5px solid var(--border)',
      borderRadius: 12,
      boxShadow: 'var(--shadow)',
      zIndex: 50,
      maxHeight: 260,
      overflowY: 'auto'
    }
  }, matches.map(p => /*#__PURE__*/React.createElement("div", {
    key: p.id,
    onClick: () => {
      setSelected(p);
      setQ('');
    },
    style: {
      padding: '10px 14px',
      cursor: 'pointer',
      borderBottom: '1px solid var(--border)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: 13
    }
  }, p.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--muted)'
    }
  }, p.pid, " \xB7 ", p.phone)))) : null), !q ? /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      color: 'var(--muted)',
      textTransform: 'uppercase',
      marginBottom: 8
    }
  }, "Recent Patients"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, patients.slice(0, 4).map(p => /*#__PURE__*/React.createElement("div", {
    key: p.id,
    onClick: () => setSelected(p),
    style: {
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      background: '#fff',
      border: '1.5px solid var(--border)',
      borderRadius: 10,
      padding: '8px 12px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 32,
      height: 32,
      borderRadius: '50%',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontWeight: 800,
      fontSize: 12,
      ...genderColor(p.gender)
    }
  }, initials(p.name)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600
    }
  }, p.name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--muted)'
    }
  }, p.pid)))))) : null);
}
window.SearchScreen = SearchScreen;
window.dmHelpers = {
  inputSm,
  labelSm,
  fmtA,
  fmtD,
  initials,
  genderColor
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/patient-records/SearchScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/patient-records/SettingsScreen.jsx
try { (() => {
function SettingsScreen({
  clinicName,
  setClinicName,
  logo,
  setLogo,
  treatments,
  setTreatments,
  consultants,
  setConsultants,
  onLockAssistant
}) {
  const {
    inputSm
  } = window.dmHelpers;
  const [newT, setNewT] = React.useState('');
  const [newC, setNewC] = React.useState('');
  const fileRef = React.useRef(null);
  const onFile = e => {
    const f = e.target.files[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = ev => setLogo(ev.target.result);
    r.readAsDataURL(f);
  };
  const Section = ({
    title,
    children
  }) => /*#__PURE__*/React.createElement("div", {
    style: {
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      color: 'var(--muted)',
      textTransform: 'uppercase',
      letterSpacing: .5,
      marginBottom: 8,
      paddingBottom: 5,
      borderBottom: '1px solid var(--border)'
    }
  }, title), children);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      border: '1.5px solid var(--border)',
      borderRadius: 14,
      boxShadow: 'var(--shadow)',
      padding: 16
    }
  }, /*#__PURE__*/React.createElement(Section, {
    title: "Clinic Branding"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: clinicName,
    onChange: e => setClinicName(e.target.value),
    placeholder: "Clinic name",
    style: {
      ...inputSm,
      flex: 1
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 16,
      alignItems: 'center'
    }
  }, logo ? /*#__PURE__*/React.createElement("img", {
    src: logo,
    style: {
      width: 56,
      height: 56,
      objectFit: 'contain',
      borderRadius: 8,
      background: 'var(--bg)',
      border: '1px solid var(--border)'
    }
  }) : null, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("label", {
    style: {
      fontSize: 10,
      fontWeight: 700,
      color: 'var(--muted)',
      letterSpacing: '.3px',
      textTransform: 'uppercase',
      display: 'block',
      marginBottom: 4
    }
  }, "Clinic Logo"), /*#__PURE__*/React.createElement("input", {
    ref: fileRef,
    type: "file",
    accept: "image/*",
    onChange: onFile
  })))), /*#__PURE__*/React.createElement(Section, {
    title: "Treatments"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 5,
      marginBottom: 8
    }
  }, treatments.map(t => /*#__PURE__*/React.createElement("span", {
    key: t,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4,
      background: 'var(--teal-l)',
      border: '1px solid var(--teal-m)',
      borderRadius: 20,
      padding: '3px 9px',
      fontSize: 11,
      color: 'var(--teal-d)'
    }
  }, t, /*#__PURE__*/React.createElement("span", {
    onClick: () => setTreatments(treatments.filter(x => x !== t)),
    style: {
      cursor: 'pointer',
      color: 'var(--red)',
      fontWeight: 700
    }
  }, "\xD7")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: newT,
    onChange: e => setNewT(e.target.value),
    placeholder: "Add new treatment\u2026",
    style: {
      ...inputSm,
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("button", {
    onClick: () => {
      if (newT) {
        setTreatments([...treatments, newT]);
        setNewT('');
      }
    },
    style: {
      padding: '6px 12px',
      borderRadius: 8,
      fontSize: 12,
      fontWeight: 700,
      border: 'none',
      background: 'var(--teal)',
      color: '#fff',
      cursor: 'pointer'
    }
  }, "+ Add"))), /*#__PURE__*/React.createElement(Section, {
    title: "Consultants"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexWrap: 'wrap',
      gap: 5,
      marginBottom: 8
    }
  }, consultants.map(c => /*#__PURE__*/React.createElement("span", {
    key: c,
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4,
      background: 'var(--teal-l)',
      border: '1px solid var(--teal-m)',
      borderRadius: 20,
      padding: '3px 9px',
      fontSize: 11,
      color: 'var(--teal-d)'
    }
  }, c, /*#__PURE__*/React.createElement("span", {
    onClick: () => setConsultants(consultants.filter(x => x !== c)),
    style: {
      cursor: 'pointer',
      color: 'var(--red)',
      fontWeight: 700
    }
  }, "\xD7")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: newC,
    onChange: e => setNewC(e.target.value),
    placeholder: "Add new consultant\u2026",
    style: {
      ...inputSm,
      flex: 1
    }
  }), /*#__PURE__*/React.createElement("button", {
    onClick: () => {
      if (newC) {
        setConsultants([...consultants, newC]);
        setNewC('');
      }
    },
    style: {
      padding: '6px 12px',
      borderRadius: 8,
      fontSize: 12,
      fontWeight: 700,
      border: 'none',
      background: 'var(--teal)',
      color: '#fff',
      cursor: 'pointer'
    }
  }, "+ Add"))), /*#__PURE__*/React.createElement(Section, {
    title: "Access"
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onLockAssistant,
    style: {
      padding: '5px 10px',
      borderRadius: 7,
      fontSize: 11,
      fontWeight: 700,
      cursor: 'pointer',
      border: '1.5px solid #fecaca',
      background: '#fee2e2',
      color: 'var(--red)'
    }
  }, "\uD83D\uDD12 Lock to Assistant Mode")));
}
window.SettingsScreen = SettingsScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/patient-records/SettingsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/patient-records/WelcomeScreen.jsx
try { (() => {
function WelcomeScreen({
  onContinue
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100vh',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'var(--bg)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: '#fff',
      borderRadius: '20px',
      padding: '32px 28px',
      width: 320,
      textAlign: 'center',
      boxShadow: 'var(--shadow-lg)'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/logo-mark.png",
    style: {
      width: 56,
      height: 56,
      objectFit: 'contain',
      marginBottom: 10
    }
  }), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontSize: 17,
      fontWeight: 800,
      marginBottom: 4
    }
  }, "Welcome to DentMemo"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 12,
      color: 'var(--muted)',
      marginBottom: 18
    }
  }, "Sign in to access your clinic's records."), /*#__PURE__*/React.createElement("button", {
    onClick: onContinue,
    style: {
      width: '100%',
      padding: 11,
      borderRadius: 10,
      border: '1.5px solid var(--border)',
      background: '#fff',
      color: '#3c4043',
      fontWeight: 600,
      fontSize: 14,
      cursor: 'pointer',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      gap: 9
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 48 48"
  }, /*#__PURE__*/React.createElement("path", {
    fill: "#EA4335",
    d: "M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "#4285F4",
    d: "M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "#FBBC05",
    d: "M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "#34A853",
    d: "M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"
  })), "Continue with Google")));
}
window.WelcomeScreen = WelcomeScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/patient-records/WelcomeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/patient-records/data.js
try { (() => {
window.SEED_TREATMENTS = ["Consult", "Cleaning", "Extraction", "RCT", "Composite Filling", "Crown Cementation", "GIC Filling", "Scaling"];
window.SEED_CONSULTANTS = ["Dr. Blessin", "Dr. Rao", "Dr. Iyer"];
window.SEED_PATIENTS = [{
  id: 1,
  pid: "PT-04821",
  name: "Aditi Rao",
  age: 34,
  gender: "F",
  phone: "9812340021"
}, {
  id: 2,
  pid: "PT-01102",
  name: "Karan Shah",
  age: 41,
  gender: "M",
  phone: "9900112233"
}, {
  id: 3,
  pid: "PT-03390",
  name: "Meera Nair",
  age: 27,
  gender: "F",
  phone: "9845098450"
}, {
  id: 4,
  pid: "PT-02207",
  name: "Rohit Sen",
  age: 52,
  gender: "M",
  phone: "9988776655"
}, {
  id: 5,
  pid: "PT-05512",
  name: "Aisha Khan",
  age: 19,
  gender: "F",
  phone: "9765432109"
}, {
  id: 6,
  pid: "PT-00931",
  name: "Vikram Joshi",
  age: 63,
  gender: "M",
  phone: "9123456780"
}, {
  id: 7,
  pid: "PT-04013",
  name: "Priya Menon",
  age: 29,
  gender: "F",
  phone: "9871234560"
}, {
  id: 8,
  pid: "PT-02650",
  name: "Arjun Nair",
  age: 8,
  gender: "M",
  phone: "9012345678"
}];
window.SEED_VISITS = [{
  id: 1,
  patientId: 1,
  date: "2026-06-02",
  diagnosis: "Dental caries #26",
  treatment: "Composite Filling",
  consultant: "Dr. Blessin",
  drFees: 800,
  clinicShare: 400,
  labCost: 0,
  remarks: ""
}, {
  id: 2,
  patientId: 1,
  date: "2026-07-10",
  diagnosis: "Routine check",
  treatment: "Cleaning",
  consultant: "Dr. Rao",
  drFees: 600,
  clinicShare: 300,
  labCost: 0,
  remarks: ""
}, {
  id: 3,
  patientId: 2,
  date: "2026-05-21",
  diagnosis: "Impacted molar",
  treatment: "Extraction",
  consultant: "Dr. Blessin",
  drFees: 1500,
  clinicShare: 600,
  labCost: 0,
  remarks: "Advised soft diet"
}, {
  id: 4,
  patientId: 3,
  date: "2026-07-01",
  diagnosis: "Pulpitis #14",
  treatment: "RCT",
  consultant: "Dr. Iyer",
  drFees: 3500,
  clinicShare: 1200,
  labCost: 400,
  remarks: ""
}, {
  id: 5,
  patientId: 3,
  date: "2026-07-22",
  diagnosis: "RCT follow-up",
  treatment: "Crown Cementation",
  consultant: "Dr. Iyer",
  drFees: 2800,
  clinicShare: 900,
  labCost: 1200,
  remarks: ""
}, {
  id: 6,
  patientId: 4,
  date: "2026-04-14",
  diagnosis: "Gum sensitivity",
  treatment: "Scaling",
  consultant: "Dr. Rao",
  drFees: 700,
  clinicShare: 350,
  labCost: 0,
  remarks: ""
}, {
  id: 7,
  patientId: 5,
  date: "2026-07-28",
  diagnosis: "Consult only",
  treatment: "Consult",
  consultant: "Dr. Blessin",
  drFees: 200,
  clinicShare: 100,
  labCost: 0,
  remarks: ""
}, {
  id: 8,
  patientId: 6,
  date: "2026-03-09",
  diagnosis: "Denture check",
  treatment: "Consult",
  consultant: "Dr. Rao",
  drFees: 200,
  clinicShare: 100,
  labCost: 0,
  remarks: ""
}, {
  id: 9,
  patientId: 7,
  date: "2026-06-18",
  diagnosis: "Cavity #36",
  treatment: "GIC Filling",
  consultant: "Dr. Iyer",
  drFees: 900,
  clinicShare: 400,
  labCost: 0,
  remarks: ""
}, {
  id: 10,
  patientId: 8,
  date: "2026-07-05",
  diagnosis: "Baby tooth extraction",
  treatment: "Extraction",
  consultant: "Dr. Blessin",
  drFees: 500,
  clinicShare: 250,
  labCost: 0,
  remarks: ""
}, {
  id: 11,
  patientId: 2,
  date: "2026-07-30",
  diagnosis: "Post-extraction check",
  treatment: "Consult",
  consultant: "Dr. Blessin",
  drFees: 200,
  clinicShare: 100,
  labCost: 0,
  remarks: ""
}, {
  id: 12,
  patientId: 5,
  date: "2026-07-30",
  diagnosis: "Cleaning",
  treatment: "Cleaning",
  consultant: "Dr. Rao",
  drFees: 600,
  clinicShare: 300,
  labCost: 0,
  remarks: ""
}];
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/patient-records/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.EmptyState = __ds_scope.EmptyState;

__ds_ns.Pill = __ds_scope.Pill;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.Field = __ds_scope.Field;

__ds_ns.SearchInput = __ds_scope.SearchInput;

})();
