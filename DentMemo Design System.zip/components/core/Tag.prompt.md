Removable teal chip for managing lists — treatments and consultants in Settings.

```jsx
<Tag onRemove={() => remove(t)}>{t}</Tag>
```
