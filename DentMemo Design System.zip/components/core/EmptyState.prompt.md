Centered placeholder for a page with no query/results yet, e.g. the Search tab before a patient is chosen.

```jsx
<EmptyState icon="🔍" message="Search a patient to view their profile and visit history"/>
```
