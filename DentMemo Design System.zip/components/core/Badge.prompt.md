Small rounded-pill label for gender and status flags in tables and patient cards.

```jsx
<Badge tone="M">Male</Badge>
<Badge tone="teal">3 visits</Badge>
```
