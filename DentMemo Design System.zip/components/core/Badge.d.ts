import * as React from "react";
export interface BadgeProps{
  /** Color tone — M/F mirror gender coding, teal is the generic accent pill, neutral is default */
  tone?: "M"|"F"|"teal"|"neutral";
  children?: React.ReactNode;
}
export function Badge(props: BadgeProps): JSX.Element;
