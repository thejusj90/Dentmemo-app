import React from "react";
export function Card({title,headerRight,children,padded=true}){
  return React.createElement("div",{style:{background:"#fff",border:"1.5px solid var(--border)",borderRadius:"14px",boxShadow:"var(--shadow)",overflow:"hidden",fontFamily:"var(--font-sans)"}},
    title?React.createElement("div",{style:{padding:"12px 16px",borderBottom:"1px solid var(--border)",display:"flex",alignItems:"center",justifyContent:"space-between",flexWrap:"wrap",gap:"8px"}},
      React.createElement("div",{style:{fontSize:"14px",fontWeight:700}},title),headerRight):null,
    React.createElement("div",{style:padded?{padding:"14px"}:null},children));
}
