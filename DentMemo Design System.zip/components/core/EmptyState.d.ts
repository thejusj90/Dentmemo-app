import * as React from "react";
export interface EmptyStateProps{
  /** Single emoji glyph shown large above the message */
  icon?: string;
  message: string;
}
export function EmptyState(props: EmptyStateProps): JSX.Element;
