import * as React from "react";
export interface SearchSuggestion{ name: string; sub: string; }
export interface SearchInputProps{
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  placeholder?: string;
  /** Rendered as a floating dropdown when non-empty */
  suggestions?: SearchSuggestion[];
  onSelect?: (s: SearchSuggestion) => void;
}
export function SearchInput(props: SearchInputProps): JSX.Element;
