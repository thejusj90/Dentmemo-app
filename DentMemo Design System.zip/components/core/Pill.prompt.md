Small boxed value+label used side-by-side to summarize a patient (visits, total spend).

```jsx
<Pill value="12" label="Visits" tone="teal"/>
```
