import React from "react";
export function SearchInput({value,onChange,placeholder="Search by name, phone, or Patient ID…",suggestions,onSelect}){
  return React.createElement("div",{style:{position:"relative",marginBottom:"12px",fontFamily:"var(--font-sans)"}},
    React.createElement("svg",{width:16,height:16,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,style:{position:"absolute",left:12,top:"50%",transform:"translateY(-50%)",color:"var(--muted)",pointerEvents:"none"}},
      React.createElement("circle",{cx:11,cy:11,r:8}),React.createElement("path",{d:"m21 21-4.35-4.35"})),
    React.createElement("input",{value,onChange,placeholder,autoComplete:"off",style:{width:"100%",padding:"12px 12px 12px 40px",border:"1.5px solid var(--border)",borderRadius:"12px",fontSize:"14px",background:"#fff",outline:"none"}}),
    suggestions&&suggestions.length>0?React.createElement("div",{style:{position:"absolute",top:"calc(100% + 4px)",left:0,right:0,background:"#fff",border:"1.5px solid var(--border)",borderRadius:"12px",boxShadow:"var(--shadow)",maxHeight:260,overflowY:"auto",zIndex:100}},
      suggestions.map((s,i)=>React.createElement("div",{key:i,onClick:()=>onSelect&&onSelect(s),style:{padding:"10px 14px",cursor:"pointer",display:"flex",flexDirection:"column",gap:2,borderBottom:i<suggestions.length-1?"1px solid var(--border)":"none"}},
        React.createElement("span",{style:{fontWeight:600,fontSize:13}},s.name),
        React.createElement("span",{style:{fontSize:11,color:"var(--muted)"}},s.sub)))):null);
}
