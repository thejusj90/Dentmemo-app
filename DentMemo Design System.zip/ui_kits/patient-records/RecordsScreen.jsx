function RecordsScreen({patients,visits,treatments,consultants,doctorMode}){
  const {inputSm,fmtA,fmtD}=window.dmHelpers;
  const [name,setName]=React.useState('');
  const [treat,setTreat]=React.useState('');
  const [cons,setCons]=React.useState('');
  const pName=id=>{const p=patients.find(x=>x.id===id);return p?p.name:'—';};
  let rows=visits.map(v=>({...v,patientName:pName(v.patientId)}));
  if(name)rows=rows.filter(r=>r.patientName.toLowerCase().includes(name.toLowerCase()));
  if(treat)rows=rows.filter(r=>r.treatment===treat);
  if(cons)rows=rows.filter(r=>r.consultant===cons);
  rows=rows.sort((a,b)=>b.date.localeCompare(a.date));

  const download=(data,scope)=>{
    const header=['Date','Patient','Diagnosis','Treatment','Consultant','Dr Fees','Clinic Share','Lab Cost','Remarks'];
    const csv=[header.join(',')].concat(data.map(r=>[r.date,r.patientName,r.diagnosis,r.treatment,r.consultant,r.drFees,r.clinicShare,r.labCost,'"'+(r.remarks||'').replace(/"/g,'""')+'"'].join(','))).join('\n');
    const blob=new Blob([csv],{type:'text/csv'});
    const a=document.createElement('a');
    a.href=URL.createObjectURL(blob);
    a.download='dentmemo-records-'+scope+'.csv';
    document.body.appendChild(a);a.click();a.remove();
  };
  const total=rows.reduce((s,r)=>s+(+r.drFees||0)+(+r.clinicShare||0),0);

  return (
    <div>
      <div style={{background:'#fff',border:'1.5px solid var(--border)',borderRadius:14,boxShadow:'var(--shadow)',padding:'10px 12px',marginBottom:10}}>
        <div style={{display:'flex',gap:8,flexWrap:'wrap',alignItems:'flex-end'}}>
          <div style={{flex:1,minWidth:140}}><input value={name} onChange={e=>setName(e.target.value)} placeholder="Patient name…" style={inputSm}/></div>
          <select value={treat} onChange={e=>setTreat(e.target.value)} style={{...inputSm,width:160}}><option value="">All treatments</option>{treatments.map(t=><option key={t}>{t}</option>)}</select>
          <select value={cons} onChange={e=>setCons(e.target.value)} style={{...inputSm,width:140}}><option value="">All consultants</option>{consultants.map(c=><option key={c}>{c}</option>)}</select>
          <button onClick={()=>{setName('');setTreat('');setCons('');}} style={{padding:'8px 10px',borderRadius:8,border:'1.5px solid var(--border)',background:'#fff',fontSize:12,cursor:'pointer'}}>✕</button>
        </div>
        {doctorMode?<div style={{marginTop:8,paddingTop:8,borderTop:'1px solid var(--border)',fontSize:12,color:'var(--muted)'}}>{rows.length} visits · Total {fmtA(total)}</div>:null}
        <div style={{display:'flex',gap:6,marginTop:8,flexWrap:'wrap'}}>
          <button onClick={()=>download(rows,'filtered')} style={{padding:'6px 10px',borderRadius:8,fontSize:11,border:'1.5px solid var(--border)',background:'#fff',cursor:'pointer'}}>⬇ CSV (Filtered)</button>
          <button onClick={()=>download(visits.map(v=>({...v,patientName:pName(v.patientId)})),'all')} style={{padding:'6px 10px',borderRadius:8,fontSize:11,border:'1.5px solid var(--border)',background:'#fff',cursor:'pointer'}}>⬇ CSV (All)</button>
        </div>
      </div>
      <div style={{background:'#fff',border:'1.5px solid var(--border)',borderRadius:14,boxShadow:'var(--shadow)',overflow:'hidden'}}>
        <div style={{overflowX:'auto'}}>
          <table style={{width:'100%',borderCollapse:'collapse',fontSize:12}}>
            <thead><tr>{['Date','Patient','Diagnosis','Treatment','Consultant'].concat(doctorMode?['Dr Fees','Clinic ₹']:[]).map(h=><th key={h} style={{padding:'8px 10px',textAlign:h.includes('₹')||h.includes('Fees')?'right':'left',fontSize:10,color:'var(--muted)',textTransform:'uppercase',background:'var(--bg)'}}>{h}</th>)}</tr></thead>
            <tbody>
              {rows.length===0?<tr><td colSpan={7} style={{padding:20,textAlign:'center',color:'var(--muted)'}}>No visits match these filters</td></tr>:rows.map(r=>(
                <tr key={r.id} style={{borderBottom:'1px solid var(--border)'}}>
                  <td style={{padding:'8px 10px',color:'var(--muted)',whiteSpace:'nowrap'}}>{fmtD(r.date)}</td>
                  <td style={{padding:'8px 10px'}}>{r.patientName}</td>
                  <td style={{padding:'8px 10px'}}>{r.diagnosis}</td>
                  <td style={{padding:'8px 10px'}}>{r.treatment}</td>
                  <td style={{padding:'8px 10px'}}>{r.consultant}</td>
                  {doctorMode?<td style={{padding:'8px 10px',textAlign:'right',fontWeight:700,color:'var(--green)'}}>{fmtA(r.drFees)}</td>:null}
                  {doctorMode?<td style={{padding:'8px 10px',textAlign:'right',fontWeight:700}}>{fmtA(r.clinicShare)}</td>:null}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
window.RecordsScreen=RecordsScreen;
