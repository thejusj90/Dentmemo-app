import React from "react";
export function EmptyState({icon="🔍",message}){
  return React.createElement("div",{style:{textAlign:"center",padding:"40px 20px",color:"var(--muted)",fontFamily:"var(--font-sans)"}},
    React.createElement("div",{style:{fontSize:"40px",marginBottom:"10px"}},icon),
    React.createElement("p",null,message));
}
