import React from "react";
export function Badge({tone="neutral",children}){
  const map={M:{background:"var(--blue-l)",color:"var(--blue)"},F:{background:"var(--pink-l)",color:"var(--pink)"},teal:{background:"var(--teal-m)",color:"var(--teal-d)"},neutral:{background:"var(--border)",color:"var(--muted)"}};
  const s=map[tone]||map.neutral;
  return React.createElement("span",{style:{display:"inline-block",padding:"2px 8px",borderRadius:"20px",fontSize:"10px",fontWeight:700,fontFamily:"var(--font-sans)",...s}},children);
}
