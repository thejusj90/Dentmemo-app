function OnboardingShell({step,total,title,subtitle,children,onBack,onNext,nextLabel="Continue",nextDisabled}){
  return (
    <div style={{minHeight:'100vh',background:'var(--bg)',display:'flex',alignItems:'center',justifyContent:'center',padding:20}}>
      <div style={{background:'#fff',borderRadius:20,padding:'28px',width:380,boxShadow:'var(--shadow-lg)'}}>
        <div style={{display:'flex',gap:4,marginBottom:18}}>
          {Array.from({length:total}).map((_,i)=>(
            <div key={i} style={{flex:1,height:3,borderRadius:2,background:i<step?'var(--teal)':'var(--border)'}}/>
          ))}
        </div>
        <h3 style={{fontSize:16,fontWeight:800,marginBottom:4}}>{title}</h3>
        {subtitle?<p style={{fontSize:12,color:'var(--muted)',marginBottom:16}}>{subtitle}</p>:null}
        <div style={{marginBottom:20}}>{children}</div>
        <div style={{display:'flex',gap:8,justifyContent:'space-between'}}>
          {onBack?<button onClick={onBack} style={{padding:'9px 14px',borderRadius:10,border:'1.5px solid var(--border)',background:'#fff',color:'var(--muted)',fontWeight:700,fontSize:13,cursor:'pointer'}}>Back</button>:<span/>}
          <button onClick={onNext} disabled={nextDisabled} style={{padding:'9px 18px',borderRadius:10,border:'none',background:'var(--teal)',color:'#fff',fontWeight:700,fontSize:13,cursor:nextDisabled?'default':'pointer',opacity:nextDisabled?.5:1}}>{nextLabel}</button>
        </div>
      </div>
    </div>
  );
}
const inputStyle={width:'100%',padding:'9px 11px',border:'1.5px solid var(--border)',borderRadius:10,fontSize:13,fontFamily:'inherit',outline:'none'};
const labelStyle={fontSize:10,fontWeight:700,color:'var(--muted)',letterSpacing:'.3px',textTransform:'uppercase',display:'block',marginBottom:4};

function ClinicSetupScreen({data,setData,onBack,onNext}){
  return (
    <OnboardingShell step={1} total={4} title="Create your clinic" subtitle="This becomes your clinic's private workspace." onBack={onBack} onNext={onNext} nextDisabled={!data.doctorName||!data.clinicName}>
      <div style={{display:'flex',flexDirection:'column',gap:12}}>
        <div><label style={labelStyle}>Doctor Name *</label><input style={inputStyle} value={data.doctorName} onChange={e=>setData({...data,doctorName:e.target.value})} placeholder="Dr. Jane Doe"/></div>
        <div><label style={labelStyle}>Clinic Name *</label><input style={inputStyle} value={data.clinicName} onChange={e=>setData({...data,clinicName:e.target.value})} placeholder="Sunrise Dental Studio"/></div>
      </div>
    </OnboardingShell>
  );
}
function LogoSetupScreen({data,setData,onBack,onNext}){
  return (
    <OnboardingShell step={2} total={4} title="Add your logo" subtitle="Optional — shown in your nav bar and login screen. You can add this later in Settings." onBack={onBack} onNext={onNext} nextLabel={data.logo?"Continue":"Skip for now"}>
      <div style={{display:'flex',flexDirection:'column',alignItems:'center',gap:10,padding:'12px 0'}}>
        <div style={{width:64,height:64,borderRadius:12,background:'var(--bg)',border:'1.5px dashed var(--border)',display:'flex',alignItems:'center',justifyContent:'center',fontSize:22,color:'var(--muted)'}}>{data.logo?'✓':'+'}</div>
        <button onClick={()=>setData({...data,logo:!data.logo})} style={{fontSize:12,color:'var(--teal)',fontWeight:700,background:'none',border:'none',cursor:'pointer'}}>{data.logo?'Logo added (demo)':'Upload image'}</button>
      </div>
    </OnboardingShell>
  );
}
function PinSetupScreen({data,setData,onBack,onNext}){
  const digits=data.pin||'';
  const press=k=>{
    if(k==='del'){setData(prev=>({...prev,pin:(prev.pin||'').slice(0,-1)}));return;}
    setData(prev=>{
      const cur=prev.pin||'';
      return cur.length<4?{...prev,pin:cur+k}:prev;
    });
  };
  return (
    <OnboardingShell step={3} total={4} title="Create a Doctor PIN" subtitle="Protects financials, exports and settings when a device is used in Assistant Mode." onBack={onBack} onNext={onNext} nextDisabled={digits.length!==4}>
      <div style={{display:'flex',justifyContent:'center',gap:10,marginBottom:16}}>
        {[0,1,2,3].map(i=><div key={i} style={{width:12,height:12,borderRadius:'50%',background:i<digits.length?'var(--teal)':'var(--border)'}}/>)}
      </div>
      <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:8}}>
        {['1','2','3','4','5','6','7','8','9','','0','del'].map((k,i)=>k===''?<span key={i}/>:(
          <button key={i} onClick={()=>press(k)} style={{padding:14,borderRadius:10,border:'1.5px solid var(--border)',background:'#fff',fontSize:16,fontWeight:700,cursor:'pointer',color:'var(--ink)'}}>{k==='del'?'⌫':k}</button>
        ))}
      </div>
    </OnboardingShell>
  );
}
function TreatmentsSetupScreen({data,setData,onBack,onNext}){
  const defaults=["Consult","Cleaning","Extraction","RCT","Composite Filling","Crown Cementation"];
  const picked=data.treatments||defaults;
  const toggle=t=>setData({...data,treatments:picked.includes(t)?picked.filter(x=>x!==t):[...picked,t]});
  return (
    <OnboardingShell step={4} total={4} title="Starter treatments" subtitle="Pre-selected — add or remove any time in Settings." onBack={onBack} onNext={onNext} nextLabel="Open DentMemo">
      <div style={{display:'flex',flexWrap:'wrap',gap:6}}>
        {defaults.map(t=>(
          <button key={t} onClick={()=>toggle(t)} style={{padding:'6px 12px',borderRadius:20,fontSize:12,fontWeight:600,cursor:'pointer',border:picked.includes(t)?'1px solid var(--teal-m)':'1.5px solid var(--border)',background:picked.includes(t)?'var(--teal-l)':'#fff',color:picked.includes(t)?'var(--teal-d)':'var(--muted)'}}>{picked.includes(t)?'✓ ':''}{t}</button>
        ))}
      </div>
    </OnboardingShell>
  );
}
Object.assign(window,{ClinicSetupScreen,LogoSetupScreen,PinSetupScreen,TreatmentsSetupScreen});
