import * as React from "react";
export interface TagProps{
  children?: React.ReactNode;
  /** Show a red × remover; omit for a static tag */
  onRemove?: () => void;
}
export function Tag(props: TagProps): JSX.Element;
